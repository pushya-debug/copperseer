import React, { useState } from 'react';
import WellnessProgramForm from '../../components/forms/WellnessProgramForm';
import { 
  Plus, 
  Search, 
  Filter, 
  Heart, 
  Users,
  Calendar,
  Award,
  TrendingUp,
  Play,
  CheckCircle,
  Clock,
  MapPin,
  Star,
  Edit
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Progress,
  Tabs,
  Tab,
  Badge
} from '@nextui-org/react';

interface WellnessProgram {
  id: string;
  title: string;
  description: string;
  category: 'fitness' | 'mental-health' | 'nutrition' | 'wellness-challenge' | 'workshop';
  instructor: string;
  startDate: string;
  endDate: string;
  location: string;
  maxParticipants: number;
  currentParticipants: number;
  status: 'upcoming' | 'active' | 'completed' | 'cancelled';
  image: string;
  price: number;
  rating: number;
  tags: string[];
}

interface ParticipantProgress {
  id: string;
  employeeId: string;
  employeeName: string;
  avatar?: string;
  department: string;
  programsEnrolled: number;
  programsCompleted: number;
  totalPoints: number;
  currentStreak: number;
  achievements: string[];
  lastActivity: string;
}

const mockWellnessPrograms: WellnessProgram[] = [
  {
    id: '1',
    title: 'Morning Yoga Sessions',
    description: 'Start your day with energizing yoga sessions designed to improve flexibility and reduce stress',
    category: 'fitness',
    instructor: 'Sarah Chen',
    startDate: '2024-02-01',
    endDate: '2024-02-29',
    location: 'Conference Room A',
    maxParticipants: 20,
    currentParticipants: 15,
    status: 'active',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1',
    price: 0,
    rating: 4.8,
    tags: ['beginner-friendly', 'stress-relief', 'flexibility']
  },
  {
    id: '2',
    title: 'Mindfulness & Meditation Workshop',
    description: 'Learn practical mindfulness techniques to manage stress and improve mental well-being',
    category: 'mental-health',
    instructor: 'Dr. Michael Torres',
    startDate: '2024-02-15',
    endDate: '2024-02-15',
    location: 'Virtual',
    maxParticipants: 50,
    currentParticipants: 32,
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1',
    price: 25,
    rating: 4.9,
    tags: ['stress-management', 'mental-health', 'virtual']
  },
  {
    id: '3',
    title: '10,000 Steps Challenge',
    description: 'Team-based walking challenge to promote daily physical activity and team bonding',
    category: 'wellness-challenge',
    instructor: 'Wellness Team',
    startDate: '2024-02-01',
    endDate: '2024-02-28',
    location: 'Company-wide',
    maxParticipants: 200,
    currentParticipants: 89,
    status: 'active',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1',
    price: 0,
    rating: 4.6,
    tags: ['team-challenge', 'fitness', 'tracking']
  },
  {
    id: '4',
    title: 'Healthy Cooking Workshop',
    description: 'Learn to prepare nutritious and delicious meals that fit your busy lifestyle',
    category: 'nutrition',
    instructor: 'Chef Maria Rodriguez',
    startDate: '2024-02-20',
    endDate: '2024-02-20',
    location: 'Kitchen Lab',
    maxParticipants: 15,
    currentParticipants: 12,
    status: 'upcoming',
    image: 'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1',
    price: 15,
    rating: 4.7,
    tags: ['nutrition', 'cooking', 'healthy-eating']
  }
];

const mockParticipantProgress: ParticipantProgress[] = [
  {
    id: '1',
    employeeId: 'EMP001',
    employeeName: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    programsEnrolled: 3,
    programsCompleted: 2,
    totalPoints: 450,
    currentStreak: 7,
    achievements: ['Early Bird', 'Consistency Champion', 'Team Player'],
    lastActivity: '2024-01-20'
  },
  {
    id: '2',
    employeeId: 'EMP002',
    employeeName: 'Mike Wilson',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    programsEnrolled: 2,
    programsCompleted: 1,
    totalPoints: 280,
    currentStreak: 3,
    achievements: ['First Steps', 'Wellness Warrior'],
    lastActivity: '2024-01-19'
  }
];

const WellnessManagement: React.FC = () => {
  const [wellnessPrograms] = useState<WellnessProgram[]>(mockWellnessPrograms);
  const [participantProgress] = useState<ParticipantProgress[]>(mockParticipantProgress);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedProgram, setSelectedProgram] = useState<WellnessProgram | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeTab, setActiveTab] = useState('programs');

  const handleAddProgram = () => {
    setSelectedProgram(null);
    setIsFormOpen(true);
  };

  const handleEditProgram = (program: WellnessProgram) => {
    setSelectedProgram(program);
    setIsFormOpen(true);
  };

  const handleSaveProgram = (programData: Partial<WellnessProgram>) => {
    console.log('Saving wellness program:', programData);
    setIsFormOpen(false);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'fitness': return 'primary';
      case 'mental-health': return 'secondary';
      case 'nutrition': return 'success';
      case 'wellness-challenge': return 'warning';
      case 'workshop': return 'danger';
      default: return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'upcoming': return 'primary';
      case 'completed': return 'default';
      case 'cancelled': return 'danger';
      default: return 'default';
    }
  };

  const totalParticipants = wellnessPrograms.reduce((sum, program) => sum + program.currentParticipants, 0);
  const activePrograms = wellnessPrograms.filter(p => p.status === 'active').length;
  const avgRating = wellnessPrograms.reduce((sum, program) => sum + program.rating, 0) / wellnessPrograms.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Wellness Programs</h1>
          <p className="text-default-500 mt-1">Promote employee health and well-being through engaging programs</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="bordered" startContent={<Calendar className="h-4 w-4" />}>
            View Calendar
          </Button>
          <Button color="primary" startContent={<Plus className="h-4 w-4" />} onPress={handleAddProgram}>
            Create Program
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Active Programs</p>
                <p className="text-2xl font-bold text-primary">{activePrograms}</p>
              </div>
              <Heart className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Total Participants</p>
                <p className="text-2xl font-bold text-success">{totalParticipants}</p>
              </div>
              <Users className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Average Rating</p>
                <p className="text-2xl font-bold text-warning">{avgRating.toFixed(1)}</p>
              </div>
              <Star className="h-8 w-8 text-warning" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Completion Rate</p>
                <p className="text-2xl font-bold text-secondary">87%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Tabs */}
      <Card>
        <CardBody className="p-0">
          <Tabs 
            selectedKey={activeTab} 
            onSelectionChange={(key) => setActiveTab(key as string)}
            className="w-full"
          >
            <Tab key="programs" title="Wellness Programs">
              <div className="p-6 space-y-6">
                {/* Filters */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <div className="flex items-center space-x-4">
                    <Input
                      placeholder="Search programs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      startContent={<Search className="h-4 w-4 text-default-400" />}
                      className="w-64"
                      variant="bordered"
                    />
                    
                    <Select
                      placeholder="All Categories"
                      className="w-48"
                      variant="bordered"
                    >
                      <SelectItem key="all">All Categories</SelectItem>
                      <SelectItem key="fitness">Fitness</SelectItem>
                      <SelectItem key="mental-health">Mental Health</SelectItem>
                      <SelectItem key="nutrition">Nutrition</SelectItem>
                      <SelectItem key="wellness-challenge">Wellness Challenge</SelectItem>
                      <SelectItem key="workshop">Workshop</SelectItem>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                      More Filters
                    </Button>
                  </div>
                </div>

                {/* Programs Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {wellnessPrograms.map((program) => (
                    <Card key={program.id} className="hover:shadow-lg transition-shadow">
                      <CardBody className="p-0">
                        <div className="relative">
                          <img
                            src={program.image}
                            alt={program.title}
                            className="w-full h-48 object-cover rounded-t-lg"
                          />
                          <div className="absolute top-3 right-3">
                            <Chip 
                              color={getStatusColor(program.status)} 
                              size="sm" 
                              variant="solid"
                            >
                              {program.status}
                            </Chip>
                          </div>
                          <div className="absolute top-3 left-3">
                            <Chip 
                              color={getCategoryColor(program.category)} 
                              size="sm" 
                              variant="flat"
                            >
                              {program.category}
                            </Chip>
                          </div>
                        </div>
                        
                        <div className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <h3 className="font-semibold text-lg">{program.title}</h3>
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-warning fill-current" />
                              <span className="text-sm">{program.rating}</span>
                            </div>
                          </div>
                          
                          <p className="text-sm text-default-600 mb-4">{program.description}</p>
                          
                          <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Instructor:</span>
                              <span>{program.instructor}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Duration:</span>
                              <span>{new Date(program.startDate).toLocaleDateString()} - {new Date(program.endDate).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Location:</span>
                              <div className="flex items-center">
                                <MapPin className="h-3 w-3 mr-1" />
                                <span>{program.location}</span>
                              </div>
                            </div>
                            
                            <div>
                              <div className="flex items-center justify-between text-sm mb-1">
                                <span className="text-default-500">Enrollment:</span>
                                <span>{program.currentParticipants}/{program.maxParticipants}</span>
                              </div>
                              <Progress 
                                value={(program.currentParticipants / program.maxParticipants) * 100} 
                                color="primary" 
                                size="sm" 
                              />
                            </div>
                            
                            <div className="flex flex-wrap gap-1">
                              {program.tags.slice(0, 3).map((tag, index) => (
                                <Chip key={index} size="sm" variant="flat" color="default">
                                  {tag}
                                </Chip>
                              ))}
                            </div>
                          </div>
                          
                          <div className="flex space-x-2 mt-4">
                            <Button size="sm" variant="bordered" className="flex-1">
                              View Details
                            </Button>
                            <Button 
                              size="sm" 
                              color="primary" 
                              startContent={<Edit className="h-4 w-4" />}
                              onPress={() => handleEditProgram(program)}
                            >
                              Edit
                            </Button>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  ))}
                </div>
              </div>
            </Tab>
            
            <Tab key="participants" title="Participant Progress">
              <div className="p-6 space-y-6">
                {/* Participant Progress Cards */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {participantProgress.map((participant) => (
                    <Card key={participant.id}>
                      <CardBody className="p-6">
                        <div className="flex items-center space-x-4 mb-4">
                          <Avatar
                            src={participant.avatar}
                            name={participant.employeeName}
                            size="lg"
                          />
                          <div>
                            <h3 className="font-semibold">{participant.employeeName}</h3>
                            <p className="text-sm text-default-500">{participant.department}</p>
                          </div>
                        </div>
                        
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-default-500">Programs Enrolled:</span>
                              <p className="font-semibold">{participant.programsEnrolled}</p>
                            </div>
                            <div>
                              <span className="text-default-500">Completed:</span>
                              <p className="font-semibold">{participant.programsCompleted}</p>
                            </div>
                            <div>
                              <span className="text-default-500">Total Points:</span>
                              <p className="font-semibold">{participant.totalPoints}</p>
                            </div>
                            <div>
                              <span className="text-default-500">Current Streak:</span>
                              <p className="font-semibold">{participant.currentStreak} days</p>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex items-center justify-between text-sm mb-1">
                              <span className="text-default-500">Progress:</span>
                              <span>{Math.round((participant.programsCompleted / participant.programsEnrolled) * 100)}%</span>
                            </div>
                            <Progress 
                              value={(participant.programsCompleted / participant.programsEnrolled) * 100} 
                              color="primary" 
                              size="sm" 
                            />
                          </div>
                          
                          <div>
                            <span className="text-sm text-default-500">Achievements:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {participant.achievements.map((achievement, index) => (
                                <Badge key={index} color="success" variant="flat">
                                  <Award className="h-3 w-3 mr-1" />
                                  {achievement}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-default-500">Last Activity:</span>
                            <span>{new Date(participant.lastActivity).toLocaleDateString()}</span>
                          </div>
                          
                          <Button size="sm" variant="bordered" className="w-full">
                            View Wellness Profile
                          </Button>
                        </div>
                      </CardBody>
                    </Card>
                  ))}
                </div>
              </div>
            </Tab>

            <Tab key="analytics" title="Analytics">
              <div className="p-6 space-y-6">
                {/* Analytics Dashboard */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Participation Trends</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-default-600">This Month</span>
                          <span className="font-semibold text-success">+25%</span>
                        </div>
                        <Progress value={75} color="success" size="sm" />
                        <p className="text-xs text-default-500">89 new enrollments this month</p>
                      </div>
                    </CardBody>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Program Completion</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-default-600">Average Rate</span>
                          <span className="font-semibold text-primary">87%</span>
                        </div>
                        <Progress value={87} color="primary" size="sm" />
                        <p className="text-xs text-default-500">Above industry standard</p>
                      </div>
                    </CardBody>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Employee Satisfaction</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-default-600">Average Rating</span>
                          <span className="font-semibold text-warning">4.7/5</span>
                        </div>
                        <Progress value={94} color="warning" size="sm" />
                        <p className="text-xs text-default-500">Based on 156 reviews</p>
                      </div>
                    </CardBody>
                  </Card>
                </div>

                {/* Charts Placeholder */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Program Categories</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="h-64 flex items-center justify-center bg-default-50 rounded-lg">
                        <div className="text-center">
                          <Heart className="h-12 w-12 text-default-400 mx-auto mb-4" />
                          <p className="text-default-500">Chart visualization would go here</p>
                        </div>
                      </div>
                    </CardBody>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Wellness Metrics</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="h-64 flex items-center justify-center bg-default-50 rounded-lg">
                        <div className="text-center">
                          <TrendingUp className="h-12 w-12 text-default-400 mx-auto mb-4" />
                          <p className="text-default-500">Chart visualization would go here</p>
                        </div>
                      </div>
                    </CardBody>
                  </Card>
                </div>
              </div>
            </Tab>
          </Tabs>
        </CardBody>
      </Card>

      <WellnessProgramForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        program={selectedProgram}
        onSave={handleSaveProgram}
      />
    </div>
  );
};

export default WellnessManagement;