import React, { useState } from 'react';
import PerformanceReviewForm from '../../components/forms/PerformanceReviewForm';
import { 
  Plus, 
  Search, 
  Filter, 
  Target, 
  TrendingUp,
  Star,
  Calendar,
  Award,
  BarChart3
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Progress,
  Tabs,
  Tab
} from '@nextui-org/react';

interface PerformanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  avatar?: string;
  department: string;
  position: string;
  currentRating: number;
  goals: {
    total: number;
    completed: number;
    inProgress: number;
  };
  lastReview: string;
  nextReview: string;
  status: 'excellent' | 'good' | 'needs-improvement' | 'poor';
}

const mockPerformanceRecords: PerformanceRecord[] = [
  {
    id: '1',
    employeeId: 'EMP001',
    employeeName: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    position: 'Senior Software Engineer',
    currentRating: 4.5,
    goals: { total: 8, completed: 6, inProgress: 2 },
    lastReview: '2023-12-15',
    nextReview: '2024-06-15',
    status: 'excellent'
  },
  {
    id: '2',
    employeeId: 'EMP002',
    employeeName: 'Mike Wilson',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    position: 'Engineering Manager',
    currentRating: 4.2,
    goals: { total: 6, completed: 4, inProgress: 2 },
    lastReview: '2023-11-20',
    nextReview: '2024-05-20',
    status: 'good'
  },
  {
    id: '3',
    employeeId: 'EMP003',
    employeeName: 'Emily Rodriguez',
    avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Marketing',
    position: 'Marketing Specialist',
    currentRating: 3.8,
    goals: { total: 5, completed: 3, inProgress: 1 },
    lastReview: '2023-10-10',
    nextReview: '2024-04-10',
    status: 'good'
  }
];

const PerformanceManagement: React.FC = () => {
  const [performanceRecords] = useState<PerformanceRecord[]>(mockPerformanceRecords);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<PerformanceRecord | null>(null);

  const handleScheduleReview = () => {
    setSelectedRecord(null);
    setIsFormOpen(true);
  };

  const handleStartReview = (record: PerformanceRecord) => {
    setSelectedRecord(record);
    setIsFormOpen(true);
  };

  const handleSaveReview = (reviewData: any) => {
    console.log('Saving performance review:', reviewData);
    setIsFormOpen(false);
  };

  const handleViewDetails = (recordId: string) => {
    console.log('Viewing performance details:', recordId);
    // Here you would open a detailed view
  };

  const handleViewAnalytics = () => {
    console.log('Opening performance analytics');
    // Here you would open analytics dashboard
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'success';
      case 'good': return 'primary';
      case 'needs-improvement': return 'warning';
      case 'poor': return 'danger';
      default: return 'default';
    }
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return 'success';
    if (rating >= 4.0) return 'primary';
    if (rating >= 3.5) return 'warning';
    return 'danger';
  };

  const avgRating = performanceRecords.reduce((sum, record) => sum + record.currentRating, 0) / performanceRecords.length;
  const totalGoals = performanceRecords.reduce((sum, record) => sum + record.goals.total, 0);
  const completedGoals = performanceRecords.reduce((sum, record) => sum + record.goals.completed, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Performance Management</h1>
          <p className="text-default-500 mt-1">Track employee performance, goals, and reviews</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="bordered" 
            startContent={<BarChart3 className="h-4 w-4" />}
            onPress={handleViewAnalytics}
          >
            Analytics
          </Button>
          <Button 
            color="primary" 
            startContent={<Plus className="h-4 w-4" />}
            onPress={handleScheduleReview}
          >
            Schedule Review
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Average Rating</p>
                <p className="text-2xl font-bold text-primary">{avgRating.toFixed(1)}/5</p>
              </div>
              <Star className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Goals Completed</p>
                <p className="text-2xl font-bold text-success">{Math.round((completedGoals / totalGoals) * 100)}%</p>
              </div>
              <Target className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Reviews Due</p>
                <p className="text-2xl font-bold text-warning">5</p>
              </div>
              <Calendar className="h-8 w-8 text-warning" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Top Performers</p>
                <p className="text-2xl font-bold text-secondary">12</p>
              </div>
              <Award className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardBody className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                startContent={<Search className="h-4 w-4 text-default-400" />}
                className="w-64"
                variant="bordered"
              />
              
              <Select
                placeholder="All Departments"
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="all">All Departments</SelectItem>
                <SelectItem key="engineering">Engineering</SelectItem>
                <SelectItem key="marketing">Marketing</SelectItem>
                <SelectItem key="sales">Sales</SelectItem>
              </Select>

              <Select
                placeholder="Performance Level"
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="all">All Levels</SelectItem>
                <SelectItem key="excellent">Excellent</SelectItem>
                <SelectItem key="good">Good</SelectItem>
                <SelectItem key="needs-improvement">Needs Improvement</SelectItem>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                More Filters
              </Button>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Performance Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {performanceRecords.map((record) => (
          <Card key={record.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center space-x-3">
                  <Avatar
                    src={record.avatar}
                    name={record.employeeName}
                    size="lg"
                  />
                  <div>
                    <h3 className="font-semibold">{record.employeeName}</h3>
                    <p className="text-sm text-default-500">{record.position}</p>
                    <p className="text-xs text-default-400">{record.department}</p>
                  </div>
                </div>
                <Chip 
                  color={getStatusColor(record.status)} 
                  size="sm" 
                  variant="flat"
                >
                  {record.status}
                </Chip>
              </div>
            </CardHeader>
            <CardBody>
              <div className="space-y-4">
                {/* Rating */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-default-600">Current Rating</span>
                    <span className="font-semibold">{record.currentRating}/5</span>
                  </div>
                  <Progress 
                    value={(record.currentRating / 5) * 100} 
                    color={getRatingColor(record.currentRating)} 
                    size="sm" 
                  />
                </div>

                {/* Goals Progress */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-default-600">Goals Progress</span>
                    <span className="text-sm">{record.goals.completed}/{record.goals.total}</span>
                  </div>
                  <Progress 
                    value={(record.goals.completed / record.goals.total) * 100} 
                    color="primary" 
                    size="sm" 
                  />
                </div>

                {/* Review Dates */}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-default-600">Last Review:</span>
                    <span>{new Date(record.lastReview).toLocaleDateString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-default-600">Next Review:</span>
                    <span>{new Date(record.nextReview).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex space-x-2 pt-2">
                  <Button 
                    size="sm" 
                    variant="bordered" 
                    className="flex-1"
                    onPress={() => handleViewDetails(record.id)}
                  >
                    View Details
                  </Button>
                  <Button 
                    size="sm" 
                    color="primary" 
                    className="flex-1"
                    onPress={() => handleStartReview(record)}
                  >
                    Start Review
                  </Button>
                </div>
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      <PerformanceReviewForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        record={selectedRecord}
        onSave={handleSaveReview}
      />
    </div>
  );
};

export default PerformanceManagement;