import React, { useState } from 'react';
import TrainingCourseForm from '../../components/forms/TrainingCourseForm';
import { 
  Plus, 
  Search, 
  Filter, 
  BookOpen, 
  Users,
  Clock,
  Award,
  Play,
  CheckCircle,
  Calendar,
  Edit
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Progress,
  Tabs,
  Tab
} from '@nextui-org/react';

interface TrainingCourse {
  id: string;
  title: string;
  description: string;
  instructor: string;
  duration: string;
  category: 'technical' | 'soft-skills' | 'compliance' | 'leadership';
  level: 'beginner' | 'intermediate' | 'advanced';
  enrolledCount: number;
  completionRate: number;
  status: 'active' | 'draft' | 'archived';
  thumbnail: string;
}

interface EmployeeTraining {
  id: string;
  employeeId: string;
  employeeName: string;
  avatar?: string;
  department: string;
  coursesEnrolled: number;
  coursesCompleted: number;
  totalHours: number;
  lastActivity: string;
  certifications: number;
}

const mockTrainingCourses: TrainingCourse[] = [
  {
    id: '1',
    title: 'React Advanced Patterns',
    description: 'Learn advanced React patterns and best practices for scalable applications',
    instructor: 'John Smith',
    duration: '8 hours',
    category: 'technical',
    level: 'advanced',
    enrolledCount: 24,
    completionRate: 85,
    status: 'active',
    thumbnail: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1'
  },
  {
    id: '2',
    title: 'Leadership Fundamentals',
    description: 'Essential leadership skills for new managers and team leads',
    instructor: 'Sarah Davis',
    duration: '12 hours',
    category: 'leadership',
    level: 'intermediate',
    enrolledCount: 18,
    completionRate: 92,
    status: 'active',
    thumbnail: 'https://images.pexels.com/photos/1181396/pexels-photo-1181396.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1'
  },
  {
    id: '3',
    title: 'Data Privacy & Security',
    description: 'Mandatory training on data protection and security protocols',
    instructor: 'Mike Johnson',
    duration: '4 hours',
    category: 'compliance',
    level: 'beginner',
    enrolledCount: 156,
    completionRate: 78,
    status: 'active',
    thumbnail: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&dpr=1'
  }
];

const mockEmployeeTraining: EmployeeTraining[] = [
  {
    id: '1',
    employeeId: 'EMP001',
    employeeName: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    coursesEnrolled: 5,
    coursesCompleted: 3,
    totalHours: 24,
    lastActivity: '2024-01-20',
    certifications: 2
  },
  {
    id: '2',
    employeeId: 'EMP002',
    employeeName: 'Mike Wilson',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    coursesEnrolled: 3,
    coursesCompleted: 2,
    totalHours: 16,
    lastActivity: '2024-01-18',
    certifications: 1
  }
];

const TrainingManagement: React.FC = () => {
  const [trainingCourses] = useState<TrainingCourse[]>(mockTrainingCourses);
  const [employeeTraining] = useState<EmployeeTraining[]>(mockEmployeeTraining);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<TrainingCourse | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeTab, setActiveTab] = useState('courses');

  const handleAddCourse = () => {
    setSelectedCourse(null);
    setIsFormOpen(true);
  };

  const handleEditCourse = (course: TrainingCourse) => {
    setSelectedCourse(course);
    setIsFormOpen(true);
  };

  const handleSaveCourse = (courseData: Partial<TrainingCourse>) => {
    console.log('Saving course:', courseData);
    // Here you would typically save to your backend
    setIsFormOpen(false);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'technical': return 'primary';
      case 'soft-skills': return 'secondary';
      case 'compliance': return 'warning';
      case 'leadership': return 'success';
      default: return 'default';
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'beginner': return 'success';
      case 'intermediate': return 'warning';
      case 'advanced': return 'danger';
      default: return 'default';
    }
  };

  const totalEnrollments = trainingCourses.reduce((sum, course) => sum + course.enrolledCount, 0);
  const avgCompletionRate = trainingCourses.reduce((sum, course) => sum + course.completionRate, 0) / trainingCourses.length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Training Management</h1>
          <p className="text-default-500 mt-1">Manage training programs and track employee development</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="bordered" startContent={<Calendar className="h-4 w-4" />}>
            Schedule Training
          </Button>
          <Button color="primary" startContent={<Plus className="h-4 w-4" />} onPress={handleAddCourse}>
            Create Course
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Active Courses</p>
                <p className="text-2xl font-bold text-primary">{trainingCourses.filter(c => c.status === 'active').length}</p>
              </div>
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Total Enrollments</p>
                <p className="text-2xl font-bold text-success">{totalEnrollments}</p>
              </div>
              <Users className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Avg. Completion</p>
                <p className="text-2xl font-bold text-warning">{Math.round(avgCompletionRate)}%</p>
              </div>
              <CheckCircle className="h-8 w-8 text-warning" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Certifications</p>
                <p className="text-2xl font-bold text-secondary">45</p>
              </div>
              <Award className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Tabs */}
      <Card>
        <CardBody className="p-0">
          <Tabs 
            selectedKey={activeTab} 
            onSelectionChange={(key) => setActiveTab(key as string)}
            className="w-full"
          >
            <Tab key="courses" title="Training Courses">
              <div className="p-6 space-y-6">
                {/* Filters */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <div className="flex items-center space-x-4">
                    <Input
                      placeholder="Search courses..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      startContent={<Search className="h-4 w-4 text-default-400" />}
                      className="w-64"
                      variant="bordered"
                    />
                    
                    <Select
                      placeholder="All Categories"
                      className="w-48"
                      variant="bordered"
                    >
                      <SelectItem key="all">All Categories</SelectItem>
                      <SelectItem key="technical">Technical</SelectItem>
                      <SelectItem key="soft-skills">Soft Skills</SelectItem>
                      <SelectItem key="compliance">Compliance</SelectItem>
                      <SelectItem key="leadership">Leadership</SelectItem>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                      More Filters
                    </Button>
                  </div>
                </div>

                {/* Course Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {trainingCourses.map((course) => (
                    <Card key={course.id} className="hover:shadow-lg transition-shadow">
                      <CardBody className="p-0">
                        <img
                          src={course.thumbnail}
                          alt={course.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <h3 className="font-semibold text-lg">{course.title}</h3>
                            <Chip 
                              color={getCategoryColor(course.category)} 
                              size="sm" 
                              variant="flat"
                            >
                              {course.category}
                            </Chip>
                          </div>
                          
                          <p className="text-sm text-default-600 mb-4">{course.description}</p>
                          
                          <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Instructor:</span>
                              <span>{course.instructor}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Duration:</span>
                              <span>{course.duration}</span>
                            </div>
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Level:</span>
                              <Chip 
                                color={getLevelColor(course.level)} 
                                size="sm" 
                                variant="flat"
                              >
                                {course.level}
                              </Chip>
                            </div>
                            
                            <div>
                              <div className="flex items-center justify-between text-sm mb-1">
                                <span className="text-default-500">Completion Rate:</span>
                                <span>{course.completionRate}%</span>
                              </div>
                              <Progress value={course.completionRate} color="primary" size="sm" />
                            </div>
                            
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-default-500">Enrolled:</span>
                              <span>{course.enrolledCount} students</span>
                            </div>
                          </div>
                          
                          <div className="flex space-x-2 mt-4">
                            <Button size="sm" variant="bordered" className="flex-1">
                              View Details
                            </Button>
                            <Button 
                              size="sm" 
                              color="primary" 
                              startContent={<Edit className="h-4 w-4" />}
                              onPress={() => handleEditCourse(course)}
                            >
                              Edit
                            </Button>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  ))}
                </div>
              </div>
            </Tab>
            
            <Tab key="employees" title="Employee Progress">
              <div className="p-6 space-y-6">
                {/* Employee Training Cards */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {employeeTraining.map((employee) => (
                    <Card key={employee.id}>
                      <CardBody className="p-6">
                        <div className="flex items-center space-x-4 mb-4">
                          <Avatar
                            src={employee.avatar}
                            name={employee.employeeName}
                            size="lg"
                          />
                          <div>
                            <h3 className="font-semibold">{employee.employeeName}</h3>
                            <p className="text-sm text-default-500">{employee.department}</p>
                          </div>
                        </div>
                        
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-default-500">Courses Enrolled:</span>
                              <p className="font-semibold">{employee.coursesEnrolled}</p>
                            </div>
                            <div>
                              <span className="text-default-500">Completed:</span>
                              <p className="font-semibold">{employee.coursesCompleted}</p>
                            </div>
                            <div>
                              <span className="text-default-500">Total Hours:</span>
                              <p className="font-semibold">{employee.totalHours}h</p>
                            </div>
                            <div>
                              <span className="text-default-500">Certifications:</span>
                              <p className="font-semibold">{employee.certifications}</p>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex items-center justify-between text-sm mb-1">
                              <span className="text-default-500">Progress:</span>
                              <span>{Math.round((employee.coursesCompleted / employee.coursesEnrolled) * 100)}%</span>
                            </div>
                            <Progress 
                              value={(employee.coursesCompleted / employee.coursesEnrolled) * 100} 
                              color="primary" 
                              size="sm" 
                            />
                          </div>
                          
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-default-500">Last Activity:</span>
                            <span>{new Date(employee.lastActivity).toLocaleDateString()}</span>
                          </div>
                          
                          <Button size="sm" variant="bordered" className="w-full">
                            View Training History
                          </Button>
                        </div>
                      </CardBody>
                    </Card>
                  ))}
                </div>
              </div>
            </Tab>
          </Tabs>
        </CardBody>
      </Card>

      <TrainingCourseForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        course={selectedCourse}
        onSave={handleSaveCourse}
      />
    </div>
  );
};

export default TrainingManagement;