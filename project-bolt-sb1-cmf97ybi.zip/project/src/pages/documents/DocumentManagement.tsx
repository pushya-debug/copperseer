import React, { useState } from 'react';
import DocumentForm from '../../components/forms/DocumentForm';
import { 
  Plus, 
  Search, 
  Filter, 
  FileText, 
  Download,
  Upload,
  Eye,
  Trash2,
  Calendar,
  User,
  FolderOpen
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Table, 
  TableHeader, 
  TableColumn, 
  TableBody, 
  TableRow, 
  TableCell,
  Tabs,
  Tab
} from '@nextui-org/react';

interface Document {
  id: string;
  name: string;
  type: 'contract' | 'policy' | 'form' | 'certificate' | 'report' | 'other';
  category: 'hr' | 'legal' | 'finance' | 'it' | 'general';
  size: string;
  uploadedBy: string;
  uploadedDate: string;
  lastModified: string;
  status: 'active' | 'archived' | 'expired';
  expiryDate?: string;
  downloadCount: number;
}

const mockDocuments: Document[] = [
  {
    id: '1',
    name: 'Employee Handbook 2024',
    type: 'policy',
    category: 'hr',
    size: '2.4 MB',
    uploadedBy: 'HR Admin',
    uploadedDate: '2024-01-15',
    lastModified: '2024-01-20',
    status: 'active',
    downloadCount: 156
  },
  {
    id: '2',
    name: 'Software License Agreement',
    type: 'contract',
    category: 'legal',
    size: '1.8 MB',
    uploadedBy: 'Legal Team',
    uploadedDate: '2024-01-10',
    lastModified: '2024-01-10',
    status: 'active',
    expiryDate: '2024-12-31',
    downloadCount: 45
  },
  {
    id: '3',
    name: 'Security Training Certificate',
    type: 'certificate',
    category: 'it',
    size: '0.5 MB',
    uploadedBy: 'IT Security',
    uploadedDate: '2024-01-08',
    lastModified: '2024-01-08',
    status: 'active',
    expiryDate: '2025-01-08',
    downloadCount: 89
  },
  {
    id: '4',
    name: 'Expense Report Template',
    type: 'form',
    category: 'finance',
    size: '0.3 MB',
    uploadedBy: 'Finance Team',
    uploadedDate: '2023-12-20',
    lastModified: '2024-01-05',
    status: 'active',
    downloadCount: 234
  }
];

const DocumentManagement: React.FC = () => {
  const [documents] = useState<Document[]>(mockDocuments);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const handleUploadDocument = () => {
    setSelectedDocument(null);
    setIsFormOpen(true);
  };

  const handleEditDocument = (document: Document) => {
    setSelectedDocument(document);
    setIsFormOpen(true);
  };

  const handleSaveDocument = (documentData: Partial<Document>) => {
    console.log('Saving document:', documentData);
    setIsFormOpen(false);
  };

  const handleViewDocument = (documentId: string) => {
    console.log('Viewing document:', documentId);
    // Here you would open the document viewer
  };

  const handleDownloadDocument = (documentId: string) => {
    console.log('Downloading document:', documentId);
    // Here you would trigger the download
  };

  const handleDeleteDocument = (documentId: string) => {
    console.log('Deleting document:', documentId);
    // Here you would delete the document
  };

  const handleBrowseFolders = () => {
    console.log('Opening folder browser');
    // Here you would open a folder browser
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'contract': return 'primary';
      case 'policy': return 'secondary';
      case 'form': return 'success';
      case 'certificate': return 'warning';
      case 'report': return 'danger';
      default: return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'archived': return 'default';
      case 'expired': return 'danger';
      default: return 'default';
    }
  };

  const totalDocuments = documents.length;
  const totalDownloads = documents.reduce((sum, doc) => sum + doc.downloadCount, 0);
  const expiringDocs = documents.filter(doc => {
    if (!doc.expiryDate) return false;
    const expiryDate = new Date(doc.expiryDate);
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    return expiryDate <= thirtyDaysFromNow;
  }).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Document Management</h1>
          <p className="text-default-500 mt-1">Organize and manage company documents and policies</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="bordered" 
            startContent={<FolderOpen className="h-4 w-4" />}
            onPress={handleBrowseFolders}
          >
            Browse Folders
          </Button>
          <Button 
            color="primary" 
            startContent={<Upload className="h-4 w-4" />}
            onPress={handleUploadDocument}
          >
            Upload Document
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Total Documents</p>
                <p className="text-2xl font-bold text-primary">{totalDocuments}</p>
              </div>
              <FileText className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Total Downloads</p>
                <p className="text-2xl font-bold text-success">{totalDownloads}</p>
              </div>
              <Download className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Expiring Soon</p>
                <p className="text-2xl font-bold text-warning">{expiringDocs}</p>
              </div>
              <Calendar className="h-8 w-8 text-warning" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Storage Used</p>
                <p className="text-2xl font-bold text-secondary">12.8 GB</p>
              </div>
              <FolderOpen className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardBody className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <Input
                placeholder="Search documents..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                startContent={<Search className="h-4 w-4 text-default-400" />}
                className="w-64"
                variant="bordered"
              />
              
              <Select
                placeholder="All Types"
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="all">All Types</SelectItem>
                <SelectItem key="contract">Contracts</SelectItem>
                <SelectItem key="policy">Policies</SelectItem>
                <SelectItem key="form">Forms</SelectItem>
                <SelectItem key="certificate">Certificates</SelectItem>
                <SelectItem key="report">Reports</SelectItem>
              </Select>

              <Select
                placeholder="All Categories"
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="all">All Categories</SelectItem>
                <SelectItem key="hr">HR</SelectItem>
                <SelectItem key="legal">Legal</SelectItem>
                <SelectItem key="finance">Finance</SelectItem>
                <SelectItem key="it">IT</SelectItem>
                <SelectItem key="general">General</SelectItem>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                More Filters
              </Button>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Documents Table */}
      <Card>
        <Table aria-label="Documents table">
          <TableHeader>
            <TableColumn>DOCUMENT</TableColumn>
            <TableColumn>TYPE</TableColumn>
            <TableColumn>CATEGORY</TableColumn>
            <TableColumn>SIZE</TableColumn>
            <TableColumn>UPLOADED BY</TableColumn>
            <TableColumn>LAST MODIFIED</TableColumn>
            <TableColumn>STATUS</TableColumn>
            <TableColumn>DOWNLOADS</TableColumn>
            <TableColumn>ACTIONS</TableColumn>
          </TableHeader>
          <TableBody>
            {documents.map((document) => (
              <TableRow key={document.id}>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <FileText className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{document.name}</p>
                      {document.expiryDate && (
                        <p className="text-xs text-default-500">
                          Expires: {new Date(document.expiryDate).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Chip 
                    color={getTypeColor(document.type)} 
                    size="sm" 
                    variant="flat"
                  >
                    {document.type}
                  </Chip>
                </TableCell>
                <TableCell>{document.category.toUpperCase()}</TableCell>
                <TableCell>{document.size}</TableCell>
                <TableCell>{document.uploadedBy}</TableCell>
                <TableCell>{new Date(document.lastModified).toLocaleDateString()}</TableCell>
                <TableCell>
                  <Chip 
                    color={getStatusColor(document.status)} 
                    size="sm" 
                    variant="flat"
                  >
                    {document.status}
                  </Chip>
                </TableCell>
                <TableCell>{document.downloadCount}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="bordered" 
                      size="sm" 
                      startContent={<Eye className="h-4 w-4" />}
                      onPress={() => handleViewDocument(document.id)}
                    >
                      View
                    </Button>
                    <Button 
                      variant="bordered" 
                      size="sm" 
                      startContent={<Download className="h-4 w-4" />}
                      onPress={() => handleDownloadDocument(document.id)}
                    >
                      Download
                    </Button>
                    <Button 
                      variant="bordered" 
                      size="sm" 
                      color="danger" 
                      startContent={<Trash2 className="h-4 w-4" />}
                      onPress={() => handleDeleteDocument(document.id)}
                    >
                      Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <DocumentForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        document={selectedDocument}
        onSave={handleSaveDocument}
      />
    </div>
  );
};

export default DocumentManagement;