import React, { useState } from 'react';
import OnboardingPlanForm from '../../components/forms/OnboardingPlanForm';
import { 
  Plus, 
  Search, 
  Filter, 
  CheckCircle, 
  Clock, 
  User,
  Calendar,
  FileText,
  AlertCircle
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Table, 
  TableHeader, 
  TableColumn, 
  TableBody, 
  TableRow, 
  TableCell,
  Progress,
  Tabs,
  Tab
} from '@nextui-org/react';

interface OnboardingTask {
  id: string;
  employeeName: string;
  employeeId: string;
  avatar?: string;
  department: string;
  startDate: string;
  tasks: {
    id: string;
    title: string;
    description: string;
    assignee: string;
    dueDate: string;
    status: 'pending' | 'in-progress' | 'completed';
    category: 'documentation' | 'equipment' | 'training' | 'access';
  }[];
  progress: number;
}

const mockOnboardingTasks: OnboardingTask[] = [
  {
    id: '1',
    employeeName: 'Alex Johnson',
    employeeId: 'EMP001',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    startDate: '2024-02-01',
    progress: 75,
    tasks: [
      {
        id: '1',
        title: 'Complete I-9 Form',
        description: 'Submit employment eligibility verification',
        assignee: 'HR Team',
        dueDate: '2024-01-30',
        status: 'completed',
        category: 'documentation'
      },
      {
        id: '2',
        title: 'Setup Laptop & Accounts',
        description: 'Configure development environment and access',
        assignee: 'IT Team',
        dueDate: '2024-02-01',
        status: 'in-progress',
        category: 'equipment'
      },
      {
        id: '3',
        title: 'Security Training',
        description: 'Complete mandatory security awareness training',
        assignee: 'Security Team',
        dueDate: '2024-02-05',
        status: 'pending',
        category: 'training'
      }
    ]
  },
  {
    id: '2',
    employeeName: 'Maria Garcia',
    employeeId: 'EMP002',
    avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Marketing',
    startDate: '2024-02-05',
    progress: 40,
    tasks: [
      {
        id: '4',
        title: 'Benefits Enrollment',
        description: 'Select health insurance and retirement plans',
        assignee: 'HR Team',
        dueDate: '2024-02-03',
        status: 'completed',
        category: 'documentation'
      },
      {
        id: '5',
        title: 'Marketing Tools Access',
        description: 'Setup access to marketing platforms and tools',
        assignee: 'Marketing Team',
        dueDate: '2024-02-05',
        status: 'pending',
        category: 'access'
      }
    ]
  }
];

const OnboardingTasks: React.FC = () => {
  const [onboardingList] = useState<OnboardingTask[]>(mockOnboardingTasks);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<OnboardingTask | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');

  const handleAddPlan = () => {
    setSelectedPlan(null);
    setIsFormOpen(true);
  };

  const handleEditPlan = (plan: OnboardingTask) => {
    setSelectedPlan(plan);
    setIsFormOpen(true);
  };

  const handleSavePlan = (planData: Partial<OnboardingTask>) => {
    console.log('Saving onboarding plan:', planData);
    setIsFormOpen(false);
  };

  const handleUpdateTask = (taskId: string, status: string) => {
    console.log('Updating task:', taskId, 'to status:', status);
    // Here you would update the task status
  };

  const handleViewCalendar = () => {
    console.log('Opening calendar view');
    // Here you would open a calendar view
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'success';
      case 'in-progress': return 'warning';
      case 'pending': return 'default';
      default: return 'default';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'documentation': return 'primary';
      case 'equipment': return 'secondary';
      case 'training': return 'warning';
      case 'access': return 'success';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Onboarding Management</h1>
          <p className="text-default-500 mt-1">Track and manage employee onboarding progress</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="bordered" 
            startContent={<Calendar className="h-4 w-4" />}
            onPress={handleViewCalendar}
          >
            Calendar View
          </Button>
          <Button 
            color="primary" 
            startContent={<Plus className="h-4 w-4" />}
            onPress={handleAddPlan}
          >
            Add Onboarding Plan
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Active Onboarding</p>
                <p className="text-2xl font-bold text-primary">8</p>
              </div>
              <User className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Completed This Month</p>
                <p className="text-2xl font-bold text-success">12</p>
              </div>
              <CheckCircle className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Overdue Tasks</p>
                <p className="text-2xl font-bold text-danger">3</p>
              </div>
              <AlertCircle className="h-8 w-8 text-danger" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Avg. Completion Time</p>
                <p className="text-2xl font-bold text-secondary">5.2 days</p>
              </div>
              <Clock className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardBody className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                startContent={<Search className="h-4 w-4 text-default-400" />}
                className="w-64"
                variant="bordered"
              />
              
              <Select
                placeholder="All Status"
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="all">All Status</SelectItem>
                <SelectItem key="active">Active</SelectItem>
                <SelectItem key="completed">Completed</SelectItem>
                <SelectItem key="overdue">Overdue</SelectItem>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                More Filters
              </Button>
              <Button variant="bordered" startContent={<Calendar className="h-4 w-4" />}>
                Calendar View
              </Button>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Onboarding List */}
      <div className="space-y-6">
        {onboardingList.map((onboarding) => (
          <Card key={onboarding.id}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center space-x-4">
                  <Avatar
                    src={onboarding.avatar}
                    name={onboarding.employeeName}
                    size="lg"
                  />
                  <div>
                    <h3 className="text-lg font-semibold">{onboarding.employeeName}</h3>
                    <p className="text-sm text-default-500">{onboarding.department} • Starts {new Date(onboarding.startDate).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-default-600">Progress</p>
                  <div className="flex items-center space-x-2">
                    <Progress value={onboarding.progress} color="primary" size="sm" className="w-24" />
                    <span className="text-sm font-medium">{onboarding.progress}%</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardBody>
              <div className="space-y-3">
                {onboarding.tasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-3 rounded-lg bg-default-50">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-full ${
                        task.status === 'completed' ? 'bg-success/20 text-success' :
                        task.status === 'in-progress' ? 'bg-warning/20 text-warning' :
                        'bg-default-200 text-default-600'
                      }`}>
                        {task.status === 'completed' ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : task.status === 'in-progress' ? (
                          <Clock className="h-4 w-4" />
                        ) : (
                          <FileText className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium">{task.title}</p>
                        <p className="text-sm text-default-500">{task.description}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Chip size="sm" color={getCategoryColor(task.category)} variant="flat">
                            {task.category}
                          </Chip>
                          <span className="text-xs text-default-400">Due: {new Date(task.dueDate).toLocaleDateString()}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Chip 
                        size="sm" 
                        color={getStatusColor(task.status)} 
                        variant="flat"
                      >
                        {task.status}
                      </Chip>
                      <Button 
                        size="sm" 
                        variant="bordered"
                        onPress={() => handleUpdateTask(task.id, 'completed')}
                      >
                        Update
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        ))}
      </div>

      <OnboardingPlanForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        plan={selectedPlan}
        onSave={handleSavePlan}
      />
    </div>
  );
};

export default OnboardingTasks;