import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  UserPlus, 
  Briefcase, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  Clock, 
  AlertCircle,
  Plus
} from 'lucide-react';
import { Card, CardBody, CardHeader, Button, Chip, Progress } from '@nextui-org/react';
import StatCard from '../components/ui/StatCard';
import { mockDashboardStats, mockLeaveRequests, mockNotifications } from '../data/mockData';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const stats = mockDashboardStats;
  const recentLeaves = mockLeaveRequests.slice(0, 5);
  const notifications = mockNotifications.slice(0, 3);

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'add-employee':
        navigate('/employees');
        break;
      case 'post-job':
        navigate('/recruitment');
        break;
      case 'view-reports':
        navigate('/reports');
        break;
      case 'manage-payroll':
        navigate('/payroll');
        break;
      default:
        break;
    }
  };

  const handleApproveLeave = (leaveId: string) => {
    console.log('Approving leave request:', leaveId);
    // Here you would typically update the leave status
  };

  const handleDenyLeave = (leaveId: string) => {
    console.log('Denying leave request:', leaveId);
    // Here you would typically update the leave status
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-default-500 mt-1">Welcome back! Here's what's happening in your organization.</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="bordered" 
            startContent={<Plus className="h-4 w-4" />}
            onPress={() => handleQuickAction('view-reports')}
          >
            Quick Actions
          </Button>
          <Button 
            color="primary" 
            startContent={<UserPlus className="h-4 w-4" />}
            onPress={() => handleQuickAction('add-employee')}
          >
            Add Employee
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <StatCard
          title="Total Employees"
          value={stats.totalEmployees}
          icon={Users}
          change="+12 this month"
          changeType="increase"
          color="primary"
        />
        <StatCard
          title="New Hires"
          value={stats.newHires}
          icon={UserPlus}
          change="+3 this week"
          changeType="increase"
          color="success"
        />
        <StatCard
          title="Open Positions"
          value={stats.openPositions}
          icon={Briefcase}
          change="2 urgent"
          changeType="neutral"
          color="warning"
        />
        <StatCard
          title="Pending Leaves"
          value={stats.pendingLeaves}
          icon={Calendar}
          change="+2 today"
          changeType="increase"
          color="secondary"
        />
        <StatCard
          title="Monthly Payroll"
          value={`$${(stats.monthlyPayroll / 1000).toFixed(0)}K`}
          icon={DollarSign}
          change="+8% vs last month"
          changeType="increase"
          color="success"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader className="pb-3">
              <h3 className="text-lg font-semibold">Recent Activity</h3>
            </CardHeader>
            <CardBody>
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <div key={notification.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-default-50 transition-colors">
                    <div className={`p-2 rounded-full ${
                      notification.type === 'success' ? 'bg-success/20 text-success' :
                      notification.type === 'warning' ? 'bg-warning/20 text-warning' :
                      notification.type === 'error' ? 'bg-danger/20 text-danger' :
                      'bg-primary/20 text-primary'
                    }`}>
                      <AlertCircle className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{notification.title}</p>
                      <p className="text-sm text-default-500">{notification.message}</p>
                      <p className="text-xs text-default-400 mt-1">
                        {new Date(notification.timestamp).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          {/* Pending Leave Requests */}
          <Card>
            <CardHeader className="pb-3">
              <h3 className="text-lg font-semibold">Pending Leave Requests</h3>
            </CardHeader>
            <CardBody>
              <div className="space-y-4">
                {recentLeaves.filter(leave => leave.status === 'pending').map((leave) => (
                  <div key={leave.id} className="flex items-center justify-between p-3 rounded-lg bg-default-50">
                    <div>
                      <p className="text-sm font-medium">{leave.employeeName}</p>
                      <p className="text-xs text-default-500">{leave.type} • {leave.days} days</p>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        variant="bordered" 
                        color="danger"
                        onPress={() => handleDenyLeave(leave.id)}
                      >
                        Deny
                      </Button>
                      <Button 
                        size="sm" 
                        color="primary"
                        onPress={() => handleApproveLeave(leave.id)}
                      >
                        Approve
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>

          {/* Performance Overview */}
          <Card>
            <CardHeader className="pb-3">
              <h3 className="text-lg font-semibold">Performance Overview</h3>
            </CardHeader>
            <CardBody>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-default-600">Average Rating</span>
                  <span className="text-sm font-medium">4.2/5</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-default-600">Reviews Completed</span>
                    <span className="text-sm font-medium">78%</span>
                  </div>
                  <Progress value={78} color="primary" size="sm" />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-default-600">Goals Met</span>
                    <span className="text-sm font-medium">85%</span>
                  </div>
                  <Progress value={85} color="success" size="sm" />
                </div>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Hiring Trends */}
        <Card>
          <CardHeader className="pb-3">
            <h3 className="text-lg font-semibold">Hiring Trends</h3>
          </CardHeader>
          <CardBody>
            <div className="h-64 flex items-center justify-center bg-default-50 rounded-lg">
              <div className="text-center">
                <TrendingUp className="h-12 w-12 text-default-400 mx-auto mb-4" />
                <p className="text-default-500">Chart visualization would go here</p>
              </div>
            </div>
          </CardBody>
        </Card>

        {/* Department Distribution */}
        <Card>
          <CardHeader className="pb-3">
            <h3 className="text-lg font-semibold">Department Distribution</h3>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-default-600">Engineering</span>
                <div className="flex items-center space-x-2">
                  <Progress value={65} color="primary" size="sm" className="w-24" />
                  <span className="text-sm font-medium">65%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-default-600">Marketing</span>
                <div className="flex items-center space-x-2">
                  <Progress value={20} color="success" size="sm" className="w-24" />
                  <span className="text-sm font-medium">20%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-default-600">Sales</span>
                <div className="flex items-center space-x-2">
                  <Progress value={15} color="warning" size="sm" className="w-24" />
                  <span className="text-sm font-medium">15%</span>
                </div>
              </div>
            </div>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;