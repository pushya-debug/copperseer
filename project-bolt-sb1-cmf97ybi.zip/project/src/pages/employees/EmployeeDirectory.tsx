import React, { useState } from 'react';
import EmployeeForm from '../../components/forms/EmployeeForm';
import MoreFiltersModal from '../../components/modals/MoreFiltersModal';
import { 
  Plus, 
  Search, 
  Filter, 
  MoreVertical, 
  Edit, 
  Trash2, 
  Mail, 
  Phone,
  Calendar,
  Grid3X3,
  List
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Table, 
  TableHeader, 
  TableColumn, 
  TableBody, 
  TableRow, 
  TableCell,
  Dropdown,
  DropdownTrigger,
  DropdownMenu,
  DropdownItem,
  ButtonGroup
} from '@nextui-org/react';
import { mockEmployees } from '../../data/mockData';
import { Employee } from '../../types';

const EmployeeDirectory: React.FC = () => {
  const [employees] = useState<Employee[]>(mockEmployees);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [isMoreFiltersOpen, setIsMoreFiltersOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const handleAddEmployee = () => {
    setSelectedEmployee(null);
    setIsFormOpen(true);
  };

  const handleEditEmployee = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsFormOpen(true);
  };

  const handleSaveEmployee = (employeeData: Partial<Employee>) => {
    console.log('Saving employee:', employeeData);
    // Here you would typically save to your backend
    setIsFormOpen(false);
  };

  const handleMoreFilters = () => {
    setIsMoreFiltersOpen(true);
  };

  const handleApplyFilters = (filters: any) => {
    console.log('Applying filters:', filters);
    // Here you would apply the filters to your data
  };

  const departments = ['all', 'Engineering', 'Marketing', 'Sales', 'HR', 'Finance'];

  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.position.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesDepartment = selectedDepartment === 'all' || employee.department === selectedDepartment;
    
    return matchesSearch && matchesDepartment;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'inactive': return 'default';
      case 'terminated': return 'danger';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Employee Directory</h1>
          <p className="text-default-500 mt-1">Manage and view all employees in your organization</p>
        </div>
        <Button color="primary" startContent={<Plus className="h-4 w-4" />} onPress={handleAddEmployee}>
          Add Employee
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardBody className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                startContent={<Search className="h-4 w-4 text-default-400" />}
                className="w-64"
                variant="bordered"
              />
              
              <Select
                placeholder="All Departments"
                selectedKeys={selectedDepartment === 'all' ? [] : [selectedDepartment]}
                onSelectionChange={(keys) => {
                  const selected = Array.from(keys)[0] as string;
                  setSelectedDepartment(selected || 'all');
                }}
                className="w-48"
                variant="bordered"
              >
                {departments.filter(dept => dept !== 'all').map(dept => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button 
                variant="bordered" 
                startContent={<Filter className="h-4 w-4" />}
                onPress={handleMoreFilters}
              >
                More Filters
              </Button>
              <ButtonGroup>
                <Button
                  variant={viewMode === 'grid' ? 'solid' : 'bordered'}
                  onPress={() => setViewMode('grid')}
                  isIconOnly
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'solid' : 'bordered'}
                  onPress={() => setViewMode('list')}
                  isIconOnly
                >
                  <List className="h-4 w-4" />
                </Button>
              </ButtonGroup>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Employee Grid */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredEmployees.map((employee) => (
            <Card key={employee.id} className="hover:shadow-lg transition-shadow">
              <CardBody className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <Avatar
                    src={employee.avatar || 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1'}
                    name={employee.name}
                    size="lg"
                    className="w-16 h-16"
                  />
                  <Dropdown>
                    <DropdownTrigger>
                      <Button isIconOnly variant="light" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownTrigger>
                    <DropdownMenu>
                      <DropdownItem startContent={<Edit className="h-4 w-4" />}>
                        Edit
                      </DropdownItem>
                      <DropdownItem startContent={<Trash2 className="h-4 w-4" />} color="danger">
                        Delete
                      </DropdownItem>
                    </DropdownMenu>
                  </Dropdown>
                </div>
                
                <div className="space-y-2 mb-4">
                  <h3 className="text-lg font-semibold">{employee.name}</h3>
                  <p className="text-sm text-default-600">{employee.position}</p>
                  <p className="text-sm text-default-500">{employee.department}</p>
                  
                  <Chip 
                    color={getStatusColor(employee.status)} 
                    size="sm" 
                    variant="flat"
                  >
                    {employee.status}
                  </Chip>
                </div>
                
                <div className="space-y-2 text-sm text-default-500 mb-4">
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 mr-2" />
                    {employee.email}
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-2" />
                    {employee.phone}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    Joined {new Date(employee.joinDate).toLocaleDateString()}
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button variant="bordered" size="sm" className="flex-1">
                    View Profile
                  </Button>
                  <Button 
                    variant="bordered" 
                    size="sm" 
                    startContent={<Edit className="h-4 w-4" />}
                    onPress={() => handleEditEmployee(employee)}
                  >
                    Edit
                  </Button>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <Table aria-label="Employee directory table">
            <TableHeader>
              <TableColumn>EMPLOYEE</TableColumn>
              <TableColumn>POSITION</TableColumn>
              <TableColumn>DEPARTMENT</TableColumn>
              <TableColumn>STATUS</TableColumn>
              <TableColumn>JOIN DATE</TableColumn>
              <TableColumn>ACTIONS</TableColumn>
            </TableHeader>
            <TableBody>
              {filteredEmployees.map((employee) => (
                <TableRow key={employee.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <Avatar
                        src={employee.avatar || 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&dpr=1'}
                        name={employee.name}
                        size="sm"
                      />
                      <div>
                        <p className="font-medium">{employee.name}</p>
                        <p className="text-sm text-default-500">{employee.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{employee.position}</TableCell>
                  <TableCell>{employee.department}</TableCell>
                  <TableCell>
                    <Chip 
                      color={getStatusColor(employee.status)} 
                      size="sm" 
                      variant="flat"
                    >
                      {employee.status}
                    </Chip>
                  </TableCell>
                  <TableCell>{new Date(employee.joinDate).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="bordered" 
                        size="sm" 
                        startContent={<Edit className="h-4 w-4" />}
                        onPress={() => handleEditEmployee(employee)}
                      >
                        Edit
                      </Button>
                      <Button variant="bordered" size="sm" color="danger" startContent={<Trash2 className="h-4 w-4" />}>
                        Delete
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Empty State */}
      {filteredEmployees.length === 0 && (
        <div className="text-center py-12">
          <div className="w-24 h-24 mx-auto bg-default-100 rounded-full flex items-center justify-center mb-4">
            <Search className="h-12 w-12 text-default-400" />
          </div>
          <h3 className="text-lg font-medium mb-2">No employees found</h3>
          <p className="text-default-500">Try adjusting your search or filter criteria</p>
        </div>
      )}

      <EmployeeForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        employee={selectedEmployee}
        onSave={handleSaveEmployee}
      />

      <MoreFiltersModal
        isOpen={isMoreFiltersOpen}
        onClose={() => setIsMoreFiltersOpen(false)}
        onApplyFilters={handleApplyFilters}
        filterType="employees"
      />
    </div>
  );
};

export default EmployeeDirectory;