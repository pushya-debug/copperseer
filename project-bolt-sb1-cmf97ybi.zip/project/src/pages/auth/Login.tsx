import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Users } from 'lucide-react';
import { 
  Card, 
  CardBody, 
  Input, 
  Button, 
  Checkbox,
  Link,
  Divider
} from '@nextui-org/react';

const Login: React.FC = () => {
  const [email, setEmail] = useState('admin@company.com');
  const [password, setPassword] = useState('password');
  const [isVisible, setIsVisible] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const toggleVisibility = () => setIsVisible(!isVisible);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const success = await login(email, password);
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Invalid email or password');
      }
    } catch (err) {
      setError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 via-background to-secondary/20 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-lg">
              <Users className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <h2 className="mt-6 text-3xl font-bold">
            Welcome to HRPro
          </h2>
          <p className="mt-2 text-default-500">
            Manage your workforce with ease
          </p>
        </div>
        
        <Card className="shadow-2xl">
          <CardBody className="p-8">
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="space-y-4">
                <Input
                  type="email"
                  label="Email address"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  isRequired
                  variant="bordered"
                />
                
                <Input
                  label="Password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  isRequired
                  variant="bordered"
                  endContent={
                    <button className="focus:outline-none" type="button" onClick={toggleVisibility}>
                      {isVisible ? (
                        <EyeOff className="h-4 w-4 text-default-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-default-400" />
                      )}
                    </button>
                  }
                  type={isVisible ? "text" : "password"}
                />
              </div>

              {error && (
                <Card className="bg-danger/10 border border-danger/20">
                  <CardBody className="p-4">
                    <p className="text-sm text-danger">{error}</p>
                  </CardBody>
                </Card>
              )}

              <div className="flex items-center justify-between">
                <Checkbox size="sm">
                  Remember me
                </Checkbox>
                <Link href="#" size="sm" color="primary">
                  Forgot password?
                </Link>
              </div>

              <Button
                type="submit"
                color="primary"
                size="lg"
                className="w-full font-semibold"
                isLoading={loading}
              >
                Sign in
              </Button>

              <Divider />

              <Card className="bg-primary/5 border border-primary/20">
                <CardBody className="p-4">
                  <p className="text-sm text-primary">
                    <strong>Demo Credentials:</strong><br />
                    Email: admin@company.com<br />
                    Password: password
                  </p>
                </CardBody>
              </Card>
            </form>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default Login;