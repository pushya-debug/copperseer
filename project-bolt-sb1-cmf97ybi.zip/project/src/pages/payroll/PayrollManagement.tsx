import React, { useState } from 'react';
import PayrollForm from '../../components/forms/PayrollForm';
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  DollarSign,
  Calendar,
  TrendingUp,
  Users,
  Eye,
  Send
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Avatar, 
  Table, 
  TableHeader, 
  TableColumn, 
  TableBody, 
  TableRow, 
  TableCell,
  Tabs,
  Tab
} from '@nextui-org/react';

interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  avatar?: string;
  department: string;
  position: string;
  payPeriod: string;
  baseSalary: number;
  overtime: number;
  bonuses: number;
  deductions: number;
  netPay: number;
  status: 'draft' | 'processed' | 'paid';
}

const mockPayrollRecords: PayrollRecord[] = [
  {
    id: '1',
    employeeId: 'EMP001',
    employeeName: 'Sarah Johnson',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    position: 'Senior Software Engineer',
    payPeriod: 'January 2024',
    baseSalary: 7916.67,
    overtime: 500,
    bonuses: 1000,
    deductions: 1200,
    netPay: 8216.67,
    status: 'paid'
  },
  {
    id: '2',
    employeeId: 'EMP002',
    employeeName: 'Mike Wilson',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Engineering',
    position: 'Engineering Manager',
    payPeriod: 'January 2024',
    baseSalary: 10000,
    overtime: 0,
    bonuses: 2000,
    deductions: 1500,
    netPay: 10500,
    status: 'processed'
  },
  {
    id: '3',
    employeeId: 'EMP003',
    employeeName: 'Emily Rodriguez',
    avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    department: 'Marketing',
    position: 'Marketing Specialist',
    payPeriod: 'January 2024',
    baseSalary: 5416.67,
    overtime: 200,
    bonuses: 500,
    deductions: 800,
    netPay: 5316.67,
    status: 'draft'
  }
];

const PayrollManagement: React.FC = () => {
  const [payrollRecords] = useState<PayrollRecord[]>(mockPayrollRecords);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<PayrollRecord | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('january-2024');

  const handleProcessPayroll = () => {
    setSelectedRecord(null);
    setIsFormOpen(true);
  };

  const handleEditRecord = (record: PayrollRecord) => {
    setSelectedRecord(record);
    setIsFormOpen(true);
  };

  const handleSaveRecord = (recordData: Partial<PayrollRecord>) => {
    console.log('Saving payroll record:', recordData);
    setIsFormOpen(false);
  };

  const handleViewRecord = (recordId: string) => {
    console.log('Viewing payroll record:', recordId);
    // Here you would open a detailed view
  };

  const handleSendPayslip = (recordId: string) => {
    console.log('Sending payslip for record:', recordId);
    // Here you would send the payslip
  };

  const handleExportReports = () => {
    console.log('Exporting payroll reports');
    // Here you would export reports
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid': return 'success';
      case 'processed': return 'warning';
      case 'draft': return 'default';
      default: return 'default';
    }
  };

  const totalPayroll = payrollRecords.reduce((sum, record) => sum + record.netPay, 0);
  const processedCount = payrollRecords.filter(r => r.status === 'processed').length;
  const paidCount = payrollRecords.filter(r => r.status === 'paid').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Payroll Management</h1>
          <p className="text-default-500 mt-1">Manage employee compensation and payroll processing</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="bordered" 
            startContent={<Download className="h-4 w-4" />}
            onPress={handleExportReports}
          >
            Export Reports
          </Button>
          <Button 
            color="primary" 
            startContent={<Plus className="h-4 w-4" />}
            onPress={handleProcessPayroll}
          >
            Process Payroll
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Total Payroll</p>
                <p className="text-2xl font-bold text-primary">${totalPayroll.toLocaleString()}</p>
              </div>
              <DollarSign className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Employees Paid</p>
                <p className="text-2xl font-bold text-success">{paidCount}</p>
              </div>
              <Users className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Pending Processing</p>
                <p className="text-2xl font-bold text-warning">{processedCount}</p>
              </div>
              <Calendar className="h-8 w-8 text-warning" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Avg. Salary</p>
                <p className="text-2xl font-bold text-secondary">${Math.round(totalPayroll / payrollRecords.length).toLocaleString()}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardBody className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                startContent={<Search className="h-4 w-4 text-default-400" />}
                className="w-64"
                variant="bordered"
              />
              
              <Select
                placeholder="Pay Period"
                selectedKeys={[selectedPeriod]}
                onSelectionChange={(keys) => setSelectedPeriod(Array.from(keys)[0] as string)}
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="january-2024">January 2024</SelectItem>
                <SelectItem key="december-2023">December 2023</SelectItem>
                <SelectItem key="november-2023">November 2023</SelectItem>
              </Select>

              <Select
                placeholder="All Status"
                className="w-48"
                variant="bordered"
              >
                <SelectItem key="all">All Status</SelectItem>
                <SelectItem key="draft">Draft</SelectItem>
                <SelectItem key="processed">Processed</SelectItem>
                <SelectItem key="paid">Paid</SelectItem>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                More Filters
              </Button>
            </div>
          </div>
        </CardBody>
      </Card>

      {/* Payroll Table */}
      <Card>
        <Table aria-label="Payroll records table">
          <TableHeader>
            <TableColumn>EMPLOYEE</TableColumn>
            <TableColumn>DEPARTMENT</TableColumn>
            <TableColumn>BASE SALARY</TableColumn>
            <TableColumn>OVERTIME</TableColumn>
            <TableColumn>BONUSES</TableColumn>
            <TableColumn>DEDUCTIONS</TableColumn>
            <TableColumn>NET PAY</TableColumn>
            <TableColumn>STATUS</TableColumn>
            <TableColumn>ACTIONS</TableColumn>
          </TableHeader>
          <TableBody>
            {payrollRecords.map((record) => (
              <TableRow key={record.id}>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Avatar
                      src={record.avatar}
                      name={record.employeeName}
                      size="sm"
                    />
                    <div>
                      <p className="font-medium">{record.employeeName}</p>
                      <p className="text-sm text-default-500">{record.position}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>{record.department}</TableCell>
                <TableCell>${record.baseSalary.toLocaleString()}</TableCell>
                <TableCell>${record.overtime.toLocaleString()}</TableCell>
                <TableCell>${record.bonuses.toLocaleString()}</TableCell>
                <TableCell>${record.deductions.toLocaleString()}</TableCell>
                <TableCell className="font-semibold">${record.netPay.toLocaleString()}</TableCell>
                <TableCell>
                  <Chip 
                    color={getStatusColor(record.status)} 
                    size="sm" 
                    variant="flat"
                  >
                    {record.status}
                  </Chip>
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Button 
                      variant="bordered" 
                      size="sm" 
                      startContent={<Eye className="h-4 w-4" />}
                      onPress={() => handleViewRecord(record.id)}
                    >
                      View
                    </Button>
                    {record.status === 'processed' && (
                      <Button 
                        color="primary" 
                        size="sm" 
                        startContent={<Send className="h-4 w-4" />}
                        onPress={() => handleSendPayslip(record.id)}
                      >
                        Send
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <PayrollForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        record={selectedRecord}
        onSave={handleSaveRecord}
      />
    </div>
  );
};

export default PayrollManagement;