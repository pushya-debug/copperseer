import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell,
  Shield,
  Palette,
  Globe,
  Database,
  Users,
  Building,
  Mail
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Switch, 
  Avatar,
  Tabs,
  Tab,
  Textarea
} from '@nextui-org/react';

const Settings: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('company');
  const [formData, setFormData] = useState({
    // Company settings
    companyName: 'TechCorp Inc.',
    industry: 'Technology',
    companySize: '150-200',
    foundedYear: '2015',
    website: 'https://techcorp.com',
    description: 'A leading technology company focused on innovative solutions.',
    phone: '+1 (555) 123-4567',
    email: 'contact@techcorp.com',
    address: '123 Tech Street, San Francisco, CA 94105',
    
    // User settings
    userRole: 'admin',
    userPermissions: {
      viewEmployees: true,
      addEmployees: true,
      editEmployees: false,
      viewPayroll: true,
      processPayroll: false,
      exportReports: false,
      systemSettings: false,
      userManagement: false,
      integrations: false
    },
    
    // Notification settings
    notifications: {
      newEmployeeOnboarding: true,
      leaveRequests: true,
      performanceReviews: false,
      payrollProcessing: true,
      systemUpdates: true,
      securityAlerts: true
    },
    
    // Security settings
    passwordPolicy: {
      minLength: 8,
      requireSpecialChars: true,
      passwordExpiration: false
    },
    twoFactorAuth: {
      requireForAdmins: true,
      optionalForEmployees: true
    }
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNestedChange = (section: string, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [field]: value
      }
    }));
  };

  const handleSaveSettings = (section: string) => {
    console.log(`Saving ${section} settings:`, formData);
    // Here you would save the settings to your backend
  };

  const handleConnectIntegration = (integration: string) => {
    console.log(`Connecting to ${integration}`);
    // Here you would handle the integration connection
  };

  const handleRegenerateApiKey = () => {
    console.log('Regenerating API key');
    // Here you would regenerate the API key
  };

  const handleViewDocumentation = () => {
    window.open('https://docs.hrpro.com', '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Settings</h1>
          <p className="text-default-500 mt-1">Manage your organization settings and preferences</p>
        </div>
      </div>

      {/* Settings Tabs */}
      <Card>
        <CardBody className="p-0">
          <Tabs 
            selectedKey={activeTab} 
            onSelectionChange={(key) => setActiveTab(key as string)}
            className="w-full"
            placement="start"
          >
            <Tab 
              key="company" 
              title={
                <div className="flex items-center space-x-2">
                  <Building className="h-4 w-4" />
                  <span>Company</span>
                </div>
              }
            >
              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Company Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input
                      label="Company Name"
                      placeholder="Enter company name"
                      value={formData.companyName}
                      onChange={(e) => handleInputChange('companyName', e.target.value)}
                      variant="bordered"
                    />
                    <Input
                      label="Industry"
                      placeholder="Enter industry"
                      value={formData.industry}
                      onChange={(e) => handleInputChange('industry', e.target.value)}
                      variant="bordered"
                    />
                    <Input
                      label="Company Size"
                      placeholder="Number of employees"
                      value={formData.companySize}
                      onChange={(e) => handleInputChange('companySize', e.target.value)}
                      variant="bordered"
                    />
                    <Input
                      label="Founded Year"
                      placeholder="Year founded"
                      value={formData.foundedYear}
                      onChange={(e) => handleInputChange('foundedYear', e.target.value)}
                      variant="bordered"
                    />
                    <Input
                      label="Website"
                      placeholder="Company website"
                      value={formData.website}
                      onChange={(e) => handleInputChange('website', e.target.value)}
                      variant="bordered"
                      className="md:col-span-2"
                    />
                    <Textarea
                      label="Company Description"
                      placeholder="Brief description of your company"
                      value={formData.description}
                      onChange={(e) => handleInputChange('description', e.target.value)}
                      variant="bordered"
                      className="md:col-span-2"
                    />
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Contact Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Input
                      label="Phone Number"
                      placeholder="Company phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      variant="bordered"
                    />
                    <Input
                      label="Email"
                      placeholder="Company email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      variant="bordered"
                    />
                    <Textarea
                      label="Address"
                      placeholder="Company address"
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      variant="bordered"
                      className="md:col-span-2"
                    />
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button color="primary" onPress={() => handleSaveSettings('company')}>
                    Save Changes
                  </Button>
                </div>
              </div>
            </Tab>

            <Tab 
              key="users" 
              title={
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4" />
                  <span>Users & Roles</span>
                </div>
              }
            >
              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">User Management</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Avatar
                          src="https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&dpr=1"
                          name="John Admin"
                          size="sm"
                        />
                        <div>
                          <p className="font-medium">John Admin</p>
                          <p className="text-sm text-default-500">admin@company.com</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Select
                          placeholder="Role"
                          selectedKeys={[formData.userRole]}
                          onSelectionChange={(keys) => handleInputChange('userRole', Array.from(keys)[0])}
                          className="w-32"
                          size="sm"
                          variant="bordered"
                        >
                          <SelectItem key="admin">Admin</SelectItem>
                          <SelectItem key="hr">HR Manager</SelectItem>
                          <SelectItem key="manager">Manager</SelectItem>
                          <SelectItem key="employee">Employee</SelectItem>
                        </Select>
                        <Switch 
                          isSelected={true} 
                          size="sm"
                          onChange={(value) => console.log('User status changed:', value)}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Role Permissions</h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Card>
                        <CardBody className="p-4">
                          <h4 className="font-medium mb-2">Employee Management</h4>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">View Employees</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.viewEmployees}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'viewEmployees', value)}
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Add Employees</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.addEmployees}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'addEmployees', value)}
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Edit Employees</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.editEmployees}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'editEmployees', value)}
                              />
                            </div>
                          </div>
                        </CardBody>
                      </Card>

                      <Card>
                        <CardBody className="p-4">
                          <h4 className="font-medium mb-2">Payroll</h4>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">View Payroll</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.viewPayroll}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'viewPayroll', value)}
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Process Payroll</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.processPayroll}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'processPayroll', value)}
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Export Reports</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.exportReports}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'exportReports', value)}
                              />
                            </div>
                          </div>
                        </CardBody>
                      </Card>

                      <Card>
                        <CardBody className="p-4">
                          <h4 className="font-medium mb-2">Settings</h4>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">System Settings</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.systemSettings}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'systemSettings', value)}
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">User Management</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.userManagement}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'userManagement', value)}
                              />
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Integrations</span>
                              <Switch 
                                size="sm" 
                                isSelected={formData.userPermissions.integrations}
                                onValueChange={(value) => handleNestedChange('userPermissions', 'integrations', value)}
                              />
                            </div>
                          </div>
                        </CardBody>
                      </Card>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button color="primary" onPress={() => handleSaveSettings('permissions')}>
                    Save Permissions
                  </Button>
                </div>
              </div>
            </Tab>

            <Tab 
              key="notifications" 
              title={
                <div className="flex items-center space-x-2">
                  <Bell className="h-4 w-4" />
                  <span>Notifications</span>
                </div>
              }
            >
              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Email Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">New Employee Onboarding</p>
                        <p className="text-sm text-default-500">Notify when new employees join</p>
                      </div>
                      <Switch 
                        isSelected={formData.notifications.newEmployeeOnboarding}
                        onValueChange={(value) => handleNestedChange('notifications', 'newEmployeeOnboarding', value)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Leave Requests</p>
                        <p className="text-sm text-default-500">Notify about pending leave requests</p>
                      </div>
                      <Switch 
                        isSelected={formData.notifications.leaveRequests}
                        onValueChange={(value) => handleNestedChange('notifications', 'leaveRequests', value)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Performance Reviews</p>
                        <p className="text-sm text-default-500">Remind about upcoming reviews</p>
                      </div>
                      <Switch 
                        isSelected={formData.notifications.performanceReviews}
                        onValueChange={(value) => handleNestedChange('notifications', 'performanceReviews', value)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Payroll Processing</p>
                        <p className="text-sm text-default-500">Notify when payroll is processed</p>
                      </div>
                      <Switch 
                        isSelected={formData.notifications.payrollProcessing}
                        onValueChange={(value) => handleNestedChange('notifications', 'payrollProcessing', value)}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">System Notifications</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">System Updates</p>
                        <p className="text-sm text-default-500">Notify about system maintenance</p>
                      </div>
                      <Switch 
                        isSelected={formData.notifications.systemUpdates}
                        onValueChange={(value) => handleNestedChange('notifications', 'systemUpdates', value)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Security Alerts</p>
                        <p className="text-sm text-default-500">Important security notifications</p>
                      </div>
                      <Switch 
                        isSelected={formData.notifications.securityAlerts}
                        onValueChange={(value) => handleNestedChange('notifications', 'securityAlerts', value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button color="primary" onPress={() => handleSaveSettings('notifications')}>
                    Save Notification Settings
                  </Button>
                </div>
              </div>
            </Tab>

            <Tab 
              key="security" 
              title={
                <div className="flex items-center space-x-2">
                  <Shield className="h-4 w-4" />
                  <span>Security</span>
                </div>
              }
            >
              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Password Policy</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Minimum Password Length</p>
                        <p className="text-sm text-default-500">Require at least 8 characters</p>
                      </div>
                      <Input
                        type="number"
                        value={formData.passwordPolicy.minLength.toString()}
                        onChange={(e) => handleNestedChange('passwordPolicy', 'minLength', parseInt(e.target.value))}
                        className="w-20"
                        size="sm"
                        variant="bordered"
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Require Special Characters</p>
                        <p className="text-sm text-default-500">Include symbols in passwords</p>
                      </div>
                      <Switch 
                        isSelected={formData.passwordPolicy.requireSpecialChars}
                        onValueChange={(value) => handleNestedChange('passwordPolicy', 'requireSpecialChars', value)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Password Expiration</p>
                        <p className="text-sm text-default-500">Force password change every 90 days</p>
                      </div>
                      <Switch 
                        isSelected={formData.passwordPolicy.passwordExpiration}
                        onValueChange={(value) => handleNestedChange('passwordPolicy', 'passwordExpiration', value)}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Two-Factor Authentication</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Require 2FA for Admins</p>
                        <p className="text-sm text-default-500">Mandatory for admin users</p>
                      </div>
                      <Switch 
                        isSelected={formData.twoFactorAuth.requireForAdmins}
                        onValueChange={(value) => handleNestedChange('twoFactorAuth', 'requireForAdmins', value)}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div>
                        <p className="font-medium">Optional 2FA for Employees</p>
                        <p className="text-sm text-default-500">Allow employees to enable 2FA</p>
                      </div>
                      <Switch 
                        isSelected={formData.twoFactorAuth.optionalForEmployees}
                        onValueChange={(value) => handleNestedChange('twoFactorAuth', 'optionalForEmployees', value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button color="primary" onPress={() => handleSaveSettings('security')}>
                    Save Security Settings
                  </Button>
                </div>
              </div>
            </Tab>

            <Tab 
              key="integrations" 
              title={
                <div className="flex items-center space-x-2">
                  <Database className="h-4 w-4" />
                  <span>Integrations</span>
                </div>
              }
            >
              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Available Integrations</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <Card>
                      <CardBody className="p-6">
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Mail className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Slack</h4>
                            <p className="text-sm text-default-500">Team communication</p>
                          </div>
                        </div>
                        <p className="text-sm text-default-600 mb-4">
                          Send notifications and updates to Slack channels
                        </p>
                        <Button 
                          variant="bordered" 
                          size="sm" 
                          className="w-full"
                          onPress={() => handleConnectIntegration('slack')}
                        >
                          Connect
                        </Button>
                      </CardBody>
                    </Card>

                    <Card>
                      <CardBody className="p-6">
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <Database className="h-5 w-5 text-green-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Google Workspace</h4>
                            <p className="text-sm text-default-500">Email & Calendar</p>
                          </div>
                        </div>
                        <p className="text-sm text-default-600 mb-4">
                          Sync with Google Calendar and Gmail
                        </p>
                        <Button 
                          color="success" 
                          size="sm" 
                          className="w-full"
                          onPress={() => console.log('Already connected to Google Workspace')}
                        >
                          Connected
                        </Button>
                      </CardBody>
                    </Card>

                    <Card>
                      <CardBody className="p-6">
                        <div className="flex items-center space-x-3 mb-4">
                          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                            <SettingsIcon className="h-5 w-5 text-purple-600" />
                          </div>
                          <div>
                            <h4 className="font-medium">Zapier</h4>
                            <p className="text-sm text-default-500">Workflow automation</p>
                          </div>
                        </div>
                        <p className="text-sm text-default-600 mb-4">
                          Automate workflows with 1000+ apps
                        </p>
                        <Button 
                          variant="bordered" 
                          size="sm" 
                          className="w-full"
                          onPress={() => handleConnectIntegration('zapier')}
                        >
                          Connect
                        </Button>
                      </CardBody>
                    </Card>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">API Settings</h3>
                  <div className="space-y-4">
                    <Input
                      label="API Key"
                      placeholder="Your API key"
                      value="hrpro_api_key_123456789"
                      variant="bordered"
                      isReadOnly
                    />
                    <div className="flex space-x-3">
                      <Button variant="bordered" onPress={handleRegenerateApiKey}>
                        Regenerate Key
                      </Button>
                      <Button variant="bordered" onPress={handleViewDocumentation}>
                        View Documentation
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Tab>
          </Tabs>
        </CardBody>
      </Card>
    </div>
  );
};

export default Settings;