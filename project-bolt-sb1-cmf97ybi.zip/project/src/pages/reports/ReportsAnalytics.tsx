import React, { useState } from 'react';
import ReportForm from '../../components/forms/ReportForm';
import { 
  Plus, 
  Search, 
  Filter, 
  BarChart3, 
  Download,
  Calendar,
  TrendingUp,
  Users,
  DollarSign,
  Clock,
  Target
} from 'lucide-react';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Input, 
  Button, 
  Select, 
  SelectItem, 
  Chip, 
  Progress,
  Tabs,
  Tab
} from '@nextui-org/react';

interface Report {
  id: string;
  name: string;
  description: string;
  category: 'hr' | 'payroll' | 'performance' | 'attendance' | 'recruitment';
  type: 'standard' | 'custom';
  lastGenerated: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  status: 'active' | 'scheduled' | 'draft';
}

const mockReports: Report[] = [
  {
    id: '1',
    name: 'Monthly Headcount Report',
    description: 'Employee count by department and status',
    category: 'hr',
    type: 'standard',
    lastGenerated: '2024-01-31',
    frequency: 'monthly',
    status: 'active'
  },
  {
    id: '2',
    name: 'Payroll Summary',
    description: 'Comprehensive payroll breakdown and analysis',
    category: 'payroll',
    type: 'standard',
    lastGenerated: '2024-01-30',
    frequency: 'monthly',
    status: 'active'
  },
  {
    id: '3',
    name: 'Performance Review Analytics',
    description: 'Performance ratings and goal completion metrics',
    category: 'performance',
    type: 'custom',
    lastGenerated: '2024-01-25',
    frequency: 'quarterly',
    status: 'active'
  },
  {
    id: '4',
    name: 'Attendance Trends',
    description: 'Employee attendance patterns and leave analysis',
    category: 'attendance',
    type: 'standard',
    lastGenerated: '2024-01-28',
    frequency: 'weekly',
    status: 'active'
  }
];

const ReportsAnalytics: React.FC = () => {
  const [reports] = useState<Report[]>(mockReports);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [activeTab, setActiveTab] = useState('reports');

  const handleCreateReport = () => {
    setSelectedReport(null);
    setIsFormOpen(true);
  };

  const handleEditReport = (report: Report) => {
    setSelectedReport(report);
    setIsFormOpen(true);
  };

  const handleSaveReport = (reportData: Partial<Report>) => {
    console.log('Saving report:', reportData);
    setIsFormOpen(false);
  };

  const handleGenerateReport = (reportId: string) => {
    console.log('Generating report:', reportId);
    // Here you would generate the report
  };

  const handleViewReport = (reportId: string) => {
    console.log('Viewing report:', reportId);
    // Here you would open the report viewer
  };

  const handleExportData = () => {
    console.log('Exporting data');
    // Here you would export data
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'hr': return 'primary';
      case 'payroll': return 'success';
      case 'performance': return 'warning';
      case 'attendance': return 'secondary';
      case 'recruitment': return 'danger';
      default: return 'default';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'scheduled': return 'warning';
      case 'draft': return 'default';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Reports & Analytics</h1>
          <p className="text-default-500 mt-1">Generate insights and track key HR metrics</p>
        </div>
        <div className="flex space-x-3">
          <Button 
            variant="bordered" 
            startContent={<Download className="h-4 w-4" />}
            onPress={handleExportData}
          >
            Export Data
          </Button>
          <Button 
            color="primary" 
            startContent={<Plus className="h-4 w-4" />}
            onPress={handleCreateReport}
          >
            Create Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Total Reports</p>
                <p className="text-2xl font-bold text-primary">{reports.length}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-primary" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Scheduled Reports</p>
                <p className="text-2xl font-bold text-success">{reports.filter(r => r.status === 'scheduled').length}</p>
              </div>
              <Calendar className="h-8 w-8 text-success" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Custom Reports</p>
                <p className="text-2xl font-bold text-warning">{reports.filter(r => r.type === 'custom').length}</p>
              </div>
              <Target className="h-8 w-8 text-warning" />
            </div>
          </CardBody>
        </Card>
        
        <Card>
          <CardBody className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-default-600">Data Sources</p>
                <p className="text-2xl font-bold text-secondary">8</p>
              </div>
              <TrendingUp className="h-8 w-8 text-secondary" />
            </div>
          </CardBody>
        </Card>
      </div>

      {/* Tabs */}
      <Card>
        <CardBody className="p-0">
          <Tabs 
            selectedKey={activeTab} 
            onSelectionChange={(key) => setActiveTab(key as string)}
            className="w-full"
          >
            <Tab key="reports" title="Reports">
              <div className="p-6 space-y-6">
                {/* Filters */}
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <div className="flex items-center space-x-4">
                    <Input
                      placeholder="Search reports..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      startContent={<Search className="h-4 w-4 text-default-400" />}
                      className="w-64"
                      variant="bordered"
                    />
                    
                    <Select
                      placeholder="All Categories"
                      className="w-48"
                      variant="bordered"
                    >
                      <SelectItem key="all">All Categories</SelectItem>
                      <SelectItem key="hr">HR</SelectItem>
                      <SelectItem key="payroll">Payroll</SelectItem>
                      <SelectItem key="performance">Performance</SelectItem>
                      <SelectItem key="attendance">Attendance</SelectItem>
                      <SelectItem key="recruitment">Recruitment</SelectItem>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Button variant="bordered" startContent={<Filter className="h-4 w-4" />}>
                      More Filters
                    </Button>
                  </div>
                </div>

                {/* Reports Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {reports.map((report) => (
                    <Card key={report.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between w-full">
                          <div>
                            <h3 className="font-semibold">{report.name}</h3>
                            <p className="text-sm text-default-500">{report.description}</p>
                          </div>
                          <div className="flex space-x-2">
                            <Chip 
                              color={getCategoryColor(report.category)} 
                              size="sm" 
                              variant="flat"
                            >
                              {report.category}
                            </Chip>
                            <Chip 
                              color={getStatusColor(report.status)} 
                              size="sm" 
                              variant="flat"
                            >
                              {report.status}
                            </Chip>
                          </div>
                        </div>
                      </CardHeader>
                      <CardBody>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-default-500">Type:</span>
                              <p className="font-medium capitalize">{report.type}</p>
                            </div>
                            <div>
                              <span className="text-default-500">Frequency:</span>
                              <p className="font-medium capitalize">{report.frequency}</p>
                            </div>
                            <div className="col-span-2">
                              <span className="text-default-500">Last Generated:</span>
                              <p className="font-medium">{new Date(report.lastGenerated).toLocaleDateString()}</p>
                            </div>
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              variant="bordered" 
                              className="flex-1"
                              onPress={() => handleViewReport(report.id)}
                            >
                              View Report
                            </Button>
                            <Button 
                              size="sm" 
                              color="primary" 
                              startContent={<Download className="h-4 w-4" />}
                              onPress={() => handleGenerateReport(report.id)}
                            >
                              Generate
                            </Button>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  ))}
                </div>
              </div>
            </Tab>
            
            <Tab key="analytics" title="Analytics Dashboard">
              <div className="p-6 space-y-6">
                {/* Key Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Employee Growth</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-default-600">This Year</span>
                          <span className="font-semibold text-success">+15%</span>
                        </div>
                        <Progress value={75} color="success" size="sm" />
                        <p className="text-xs text-default-500">24 new hires this quarter</p>
                      </div>
                    </CardBody>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Retention Rate</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-default-600">12 Months</span>
                          <span className="font-semibold text-primary">92%</span>
                        </div>
                        <Progress value={92} color="primary" size="sm" />
                        <p className="text-xs text-default-500">Above industry average</p>
                      </div>
                    </CardBody>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Training Completion</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-default-600">This Quarter</span>
                          <span className="font-semibold text-warning">78%</span>
                        </div>
                        <Progress value={78} color="warning" size="sm" />
                        <p className="text-xs text-default-500">156 courses completed</p>
                      </div>
                    </CardBody>
                  </Card>
                </div>

                {/* Charts Placeholder */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Department Distribution</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="h-64 flex items-center justify-center bg-default-50 rounded-lg">
                        <div className="text-center">
                          <BarChart3 className="h-12 w-12 text-default-400 mx-auto mb-4" />
                          <p className="text-default-500">Chart visualization would go here</p>
                        </div>
                      </div>
                    </CardBody>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-3">
                      <h3 className="font-semibold">Performance Trends</h3>
                    </CardHeader>
                    <CardBody>
                      <div className="h-64 flex items-center justify-center bg-default-50 rounded-lg">
                        <div className="text-center">
                          <TrendingUp className="h-12 w-12 text-default-400 mx-auto mb-4" />
                          <p className="text-default-500">Chart visualization would go here</p>
                        </div>
                      </div>
                    </CardBody>
                  </Card>
                </div>
              </div>
            </Tab>
          </Tabs>
        </CardBody>
      </Card>

      <ReportForm
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        report={selectedReport}
        onSave={handleSaveReport}
      />
    </div>
  );
};

export default ReportsAnalytics;