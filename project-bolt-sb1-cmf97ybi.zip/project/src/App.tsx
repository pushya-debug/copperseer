import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import ProtectedRoute from './components/common/ProtectedRoute';
import Layout from './components/layout/Layout';
import Login from './pages/auth/Login';
import Dashboard from './pages/Dashboard';
import EmployeeDirectory from './pages/employees/EmployeeDirectory';
import JobListings from './pages/recruitment/JobListings';
import LeaveManagement from './pages/leave/LeaveManagement';
import OnboardingTasks from './pages/onboarding/OnboardingTasks';
import PayrollManagement from './pages/payroll/PayrollManagement';
import PerformanceManagement from './pages/performance/PerformanceManagement';
import TrainingManagement from './pages/training/TrainingManagement';
import DocumentManagement from './pages/documents/DocumentManagement';
import ReportsAnalytics from './pages/reports/ReportsAnalytics';
import WellnessManagement from './pages/wellness/WellnessManagement';
import Settings from './pages/settings/Settings';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <div className="min-h-screen bg-background text-foreground">
          <Router>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/" element={
                <ProtectedRoute>
                  <Layout />
                </ProtectedRoute>
              }>
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="employees" element={<EmployeeDirectory />} />
                <Route path="recruitment" element={<JobListings />} />
                <Route path="leave" element={<LeaveManagement />} />
                <Route path="onboarding" element={<OnboardingTasks />} />
                <Route path="payroll" element={<PayrollManagement />} />
                <Route path="performance" element={<PerformanceManagement />} />
                <Route path="training" element={<TrainingManagement />} />
                <Route path="wellness" element={<WellnessManagement />} />
                <Route path="documents" element={<DocumentManagement />} />
                <Route path="reports" element={<ReportsAnalytics />} />
                <Route path="settings" element={<Settings />} />
              </Route>
            </Routes>
          </Router>
        </div>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;