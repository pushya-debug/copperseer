import React, { useState } from 'react';
import { 
  Navbar, 
  NavbarContent, 
  NavbarItem, 
  Input, 
  Button, 
  Badge, 
  Avatar, 
  Dropdown, 
  DropdownTrigger, 
  DropdownMenu, 
  DropdownItem,
  Switch
} from '@nextui-org/react';
import { Menu, Bell, Search, User, Settings, LogOut, Sun, Moon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

interface HeaderProps {
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();

  return (
    <Navbar 
      isBordered 
      className="bg-background/70 backdrop-blur-md"
      maxWidth="full"
    >
      <NavbarContent justify="start">
        <NavbarItem>
          <Button
            isIconOnly
            variant="light"
            onPress={onMenuClick}
            className="lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </NavbarItem>
        
        <NavbarItem className="hidden lg:flex">
          <Input
            classNames={{
              base: "max-w-full sm:max-w-[20rem] h-10",
              mainWrapper: "h-full",
              input: "text-small",
              inputWrapper: "h-full font-normal text-default-500 bg-default-400/20 dark:bg-default-500/20",
            }}
            placeholder="Search employees, jobs, documents..."
            size="sm"
            startContent={<Search className="h-4 w-4" />}
            type="search"
          />
        </NavbarItem>
      </NavbarContent>

      <NavbarContent justify="end">
        <NavbarItem>
          <Switch
            defaultSelected={theme === 'dark'}
            size="sm"
            color="primary"
            thumbIcon={({ isSelected, className }) =>
              isSelected ? (
                <Moon className={className} />
              ) : (
                <Sun className={className} />
              )
            }
            onChange={toggleTheme}
          />
        </NavbarItem>
        
        <NavbarItem>
          <Badge content="3" color="danger" size="sm">
            <Button isIconOnly variant="light" radius="full">
              <Bell className="h-5 w-5" />
            </Button>
          </Badge>
        </NavbarItem>

        <NavbarItem>
          <Dropdown placement="bottom-end">
            <DropdownTrigger>
              <Avatar
                isBordered
                as="button"
                className="transition-transform"
                color="primary"
                name={user?.name}
                size="sm"
                src={user?.avatar || 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&dpr=1'}
              />
            </DropdownTrigger>
            <DropdownMenu aria-label="Profile Actions" variant="flat">
              <DropdownItem key="profile" className="h-14 gap-2">
                <p className="font-semibold">{user?.name}</p>
                <p className="text-small text-default-500">{user?.email}</p>
              </DropdownItem>
              <DropdownItem key="settings" startContent={<Settings className="h-4 w-4" />}>
                Settings
              </DropdownItem>
              <DropdownItem key="profile_page" startContent={<User className="h-4 w-4" />}>
                Profile
              </DropdownItem>
              <DropdownItem 
                key="logout" 
                color="danger" 
                startContent={<LogOut className="h-4 w-4" />}
                onPress={logout}
              >
                Sign Out
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </NavbarItem>
      </NavbarContent>
    </Navbar>
  );
};

export default Header;