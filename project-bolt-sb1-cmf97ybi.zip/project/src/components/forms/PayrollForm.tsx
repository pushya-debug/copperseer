import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Card,
  CardBody,
  Divider,
  Chip
} from '@nextui-org/react';
import { DollarSign, Calculator, Calendar, User } from 'lucide-react';

interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  position: string;
  payPeriod: string;
  baseSalary: number;
  overtime: number;
  bonuses: number;
  deductions: number;
  netPay: number;
  status: 'draft' | 'processed' | 'paid';
}

interface PayrollFormProps {
  isOpen: boolean;
  onClose: () => void;
  record?: PayrollRecord | null;
  onSave: (record: Partial<PayrollRecord>) => void;
}

const PayrollForm: React.FC<PayrollFormProps> = ({ 
  isOpen, 
  onClose, 
  record, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    employeeName: record?.employeeName || '',
    employeeId: record?.employeeId || '',
    department: record?.department || '',
    position: record?.position || '',
    payPeriod: record?.payPeriod || '',
    baseSalary: record?.baseSalary || 0,
    overtime: record?.overtime || 0,
    bonuses: record?.bonuses || 0,
    deductions: record?.deductions || 0,
    status: record?.status || 'draft',
    
    // Additional fields
    regularHours: 160,
    overtimeHours: 0,
    hourlyRate: 0,
    commissions: 0,
    allowances: 0,
    
    // Deduction details
    federalTax: 0,
    stateTax: 0,
    socialSecurity: 0,
    medicare: 0,
    healthInsurance: 0,
    retirement401k: 0,
    otherDeductions: 0
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const calculateNetPay = () => {
    const grossPay = formData.baseSalary + formData.overtime + formData.bonuses + formData.commissions + formData.allowances;
    const totalDeductions = formData.federalTax + formData.stateTax + formData.socialSecurity + 
                           formData.medicare + formData.healthInsurance + formData.retirement401k + 
                           formData.otherDeductions;
    return grossPay - totalDeductions;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.employeeName.trim()) newErrors.employeeName = 'Employee name is required';
    if (!formData.payPeriod.trim()) newErrors.payPeriod = 'Pay period is required';
    if (formData.baseSalary <= 0) newErrors.baseSalary = 'Base salary must be greater than 0';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      const netPay = calculateNetPay();
      const totalDeductions = formData.federalTax + formData.stateTax + formData.socialSecurity + 
                             formData.medicare + formData.healthInsurance + formData.retirement401k + 
                             formData.otherDeductions;
      
      onSave({
        ...formData,
        deductions: totalDeductions,
        netPay
      });
      onClose();
    }
  };

  const grossPay = formData.baseSalary + formData.overtime + formData.bonuses + formData.commissions + formData.allowances;
  const totalDeductions = formData.federalTax + formData.stateTax + formData.socialSecurity + 
                         formData.medicare + formData.healthInsurance + formData.retirement401k + 
                         formData.otherDeductions;
  const netPay = grossPay - totalDeductions;

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
    >
      <ModalContent>
        <ModalHeader>
          {record ? 'Edit Payroll Record' : 'Process Payroll'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Employee Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Employee Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Employee Name"
                    placeholder="Enter employee name"
                    value={formData.employeeName}
                    onChange={(e) => handleInputChange('employeeName', e.target.value)}
                    isRequired
                    errorMessage={errors.employeeName}
                    isInvalid={!!errors.employeeName}
                    variant="bordered"
                    startContent={<User className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Employee ID"
                    placeholder="Enter employee ID"
                    value={formData.employeeId}
                    onChange={(e) => handleInputChange('employeeId', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Department"
                    placeholder="Enter department"
                    value={formData.department}
                    onChange={(e) => handleInputChange('department', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Position"
                    placeholder="Enter position"
                    value={formData.position}
                    onChange={(e) => handleInputChange('position', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Pay Period"
                    placeholder="e.g. January 2024"
                    value={formData.payPeriod}
                    onChange={(e) => handleInputChange('payPeriod', e.target.value)}
                    isRequired
                    errorMessage={errors.payPeriod}
                    isInvalid={!!errors.payPeriod}
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />
                </div>
              </CardBody>
            </Card>

            {/* Earnings */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Earnings</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Base Salary"
                    placeholder="Monthly base salary"
                    type="number"
                    value={formData.baseSalary.toString()}
                    onChange={(e) => handleInputChange('baseSalary', parseFloat(e.target.value) || 0)}
                    isRequired
                    errorMessage={errors.baseSalary}
                    isInvalid={!!errors.baseSalary}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Overtime Pay"
                    placeholder="Overtime earnings"
                    type="number"
                    value={formData.overtime.toString()}
                    onChange={(e) => handleInputChange('overtime', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Bonuses"
                    placeholder="Performance bonuses"
                    type="number"
                    value={formData.bonuses.toString()}
                    onChange={(e) => handleInputChange('bonuses', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Commissions"
                    placeholder="Sales commissions"
                    type="number"
                    value={formData.commissions.toString()}
                    onChange={(e) => handleInputChange('commissions', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Allowances"
                    placeholder="Travel, meal allowances"
                    type="number"
                    value={formData.allowances.toString()}
                    onChange={(e) => handleInputChange('allowances', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />
                </div>

                <div className="p-4 bg-success/10 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Gross Pay:</span>
                    <span className="text-xl font-bold text-success">${grossPay.toLocaleString()}</span>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Deductions */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Deductions</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Federal Tax"
                    placeholder="Federal income tax"
                    type="number"
                    value={formData.federalTax.toString()}
                    onChange={(e) => handleInputChange('federalTax', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="State Tax"
                    placeholder="State income tax"
                    type="number"
                    value={formData.stateTax.toString()}
                    onChange={(e) => handleInputChange('stateTax', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Social Security"
                    placeholder="Social Security tax"
                    type="number"
                    value={formData.socialSecurity.toString()}
                    onChange={(e) => handleInputChange('socialSecurity', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Medicare"
                    placeholder="Medicare tax"
                    type="number"
                    value={formData.medicare.toString()}
                    onChange={(e) => handleInputChange('medicare', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Health Insurance"
                    placeholder="Health insurance premium"
                    type="number"
                    value={formData.healthInsurance.toString()}
                    onChange={(e) => handleInputChange('healthInsurance', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="401(k) Contribution"
                    placeholder="Retirement contribution"
                    type="number"
                    value={formData.retirement401k.toString()}
                    onChange={(e) => handleInputChange('retirement401k', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Other Deductions"
                    placeholder="Other deductions"
                    type="number"
                    value={formData.otherDeductions.toString()}
                    onChange={(e) => handleInputChange('otherDeductions', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                    className="md:col-span-2"
                  />
                </div>

                <div className="p-4 bg-danger/10 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Total Deductions:</span>
                    <span className="text-xl font-bold text-danger">${totalDeductions.toLocaleString()}</span>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Summary */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Payroll Summary</h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Gross Pay:</span>
                    <span className="font-semibold">${grossPay.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Total Deductions:</span>
                    <span className="font-semibold text-danger">-${totalDeductions.toLocaleString()}</span>
                  </div>
                  <Divider />
                  <div className="flex items-center justify-between text-lg">
                    <span className="font-bold">Net Pay:</span>
                    <span className="font-bold text-primary">${netPay.toLocaleString()}</span>
                  </div>
                </div>

                <div className="mt-4">
                  <Select
                    label="Status"
                    placeholder="Select status"
                    selectedKeys={[formData.status]}
                    onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                    variant="bordered"
                    className="max-w-xs"
                  >
                    <SelectItem key="draft">Draft</SelectItem>
                    <SelectItem key="processed">Processed</SelectItem>
                    <SelectItem key="paid">Paid</SelectItem>
                  </Select>
                </div>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {record ? 'Update Record' : 'Process Payroll'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default PayrollForm;