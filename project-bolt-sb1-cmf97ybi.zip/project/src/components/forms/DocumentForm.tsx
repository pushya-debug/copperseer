import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Card,
  CardBody,
  Chip,
  Progress
} from '@nextui-org/react';
import { Upload, FileText, Calendar, User, Tag, X, Plus } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: 'contract' | 'policy' | 'form' | 'certificate' | 'report' | 'other';
  category: 'hr' | 'legal' | 'finance' | 'it' | 'general';
  size: string;
  uploadedBy: string;
  uploadedDate: string;
  lastModified: string;
  status: 'active' | 'archived' | 'expired';
  expiryDate?: string;
  downloadCount: number;
}

interface DocumentFormProps {
  isOpen: boolean;
  onClose: () => void;
  document?: Document | null;
  onSave: (document: Partial<Document>) => void;
}

const DocumentForm: React.FC<DocumentFormProps> = ({ 
  isOpen, 
  onClose, 
  document, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    name: document?.name || '',
    type: document?.type || 'other',
    category: document?.category || 'general',
    status: document?.status || 'active',
    expiryDate: document?.expiryDate || '',
    description: '',
    tags: [] as string[],
    accessLevel: 'internal',
    version: '1.0',
    author: '',
    department: '',
    relatedDocuments: [] as string[],
    keywords: '',
    language: 'english',
    confidentialityLevel: 'public'
  });

  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [newTag, setNewTag] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      if (!formData.name) {
        handleInputChange('name', file.name.replace(/\.[^/.]+$/, ''));
      }
      
      // Simulate upload progress
      setIsUploading(true);
      setUploadProgress(0);
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            return 100;
          }
          return prev + 10;
        });
      }, 200);
    }
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const removeTag = (index: number) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) newErrors.name = 'Document name is required';
    if (!selectedFile && !document) newErrors.file = 'Please select a file to upload';
    if (!formData.author.trim()) newErrors.author = 'Author is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSave({
        ...formData,
        size: selectedFile ? `${(selectedFile.size / 1024 / 1024).toFixed(1)} MB` : document?.size,
        uploadedBy: formData.author,
        uploadedDate: document?.uploadedDate || new Date().toISOString().split('T')[0],
        lastModified: new Date().toISOString().split('T')[0],
        downloadCount: document?.downloadCount || 0
      });
      onClose();
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'contract': return 'primary';
      case 'policy': return 'secondary';
      case 'form': return 'success';
      case 'certificate': return 'warning';
      case 'report': return 'danger';
      default: return 'default';
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
    >
      <ModalContent>
        <ModalHeader>
          {document ? 'Edit Document' : 'Upload New Document'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* File Upload */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">File Upload</h3>
                
                <div className="border-2 border-dashed border-default-300 rounded-lg p-8 text-center">
                  {selectedFile ? (
                    <div className="space-y-4">
                      <FileText className="h-12 w-12 text-primary mx-auto" />
                      <div>
                        <p className="font-medium">{selectedFile.name}</p>
                        <p className="text-sm text-default-500">
                          {(selectedFile.size / 1024 / 1024).toFixed(1)} MB
                        </p>
                      </div>
                      {isUploading && (
                        <div className="space-y-2">
                          <Progress value={uploadProgress} color="primary" size="sm" />
                          <p className="text-sm text-default-500">Uploading... {uploadProgress}%</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Upload className="h-12 w-12 text-default-400 mx-auto" />
                      <div>
                        <p className="text-lg font-medium">Drop files here or click to browse</p>
                        <p className="text-sm text-default-500">
                          Supports PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX up to 50MB
                        </p>
                      </div>
                      <input
                        type="file"
                        onChange={handleFileSelect}
                        accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx"
                        className="hidden"
                        id="file-upload"
                      />
                      <label htmlFor="file-upload">
                        <Button as="span" color="primary">
                          Choose File
                        </Button>
                      </label>
                    </div>
                  )}
                </div>
                
                {errors.file && (
                  <p className="text-danger text-sm">{errors.file}</p>
                )}
              </CardBody>
            </Card>

            {/* Document Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Document Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Document Name"
                    placeholder="Enter document name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    isRequired
                    errorMessage={errors.name}
                    isInvalid={!!errors.name}
                    variant="bordered"
                  />

                  <Input
                    label="Author"
                    placeholder="Document author"
                    value={formData.author}
                    onChange={(e) => handleInputChange('author', e.target.value)}
                    isRequired
                    errorMessage={errors.author}
                    isInvalid={!!errors.author}
                    variant="bordered"
                    startContent={<User className="h-4 w-4 text-default-400" />}
                  />

                  <Select
                    label="Document Type"
                    placeholder="Select type"
                    selectedKeys={[formData.type]}
                    onSelectionChange={(keys) => handleInputChange('type', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="contract">Contract</SelectItem>
                    <SelectItem key="policy">Policy</SelectItem>
                    <SelectItem key="form">Form</SelectItem>
                    <SelectItem key="certificate">Certificate</SelectItem>
                    <SelectItem key="report">Report</SelectItem>
                    <SelectItem key="other">Other</SelectItem>
                  </Select>

                  <Select
                    label="Category"
                    placeholder="Select category"
                    selectedKeys={[formData.category]}
                    onSelectionChange={(keys) => handleInputChange('category', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="hr">HR</SelectItem>
                    <SelectItem key="legal">Legal</SelectItem>
                    <SelectItem key="finance">Finance</SelectItem>
                    <SelectItem key="it">IT</SelectItem>
                    <SelectItem key="general">General</SelectItem>
                  </Select>

                  <Input
                    label="Version"
                    placeholder="e.g. 1.0, 2.1"
                    value={formData.version}
                    onChange={(e) => handleInputChange('version', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Department"
                    placeholder="Originating department"
                    value={formData.department}
                    onChange={(e) => handleInputChange('department', e.target.value)}
                    variant="bordered"
                  />

                  <Select
                    label="Language"
                    placeholder="Select language"
                    selectedKeys={[formData.language]}
                    onSelectionChange={(keys) => handleInputChange('language', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="english">English</SelectItem>
                    <SelectItem key="spanish">Spanish</SelectItem>
                    <SelectItem key="french">French</SelectItem>
                    <SelectItem key="german">German</SelectItem>
                  </Select>

                  <Select
                    label="Access Level"
                    placeholder="Select access level"
                    selectedKeys={[formData.accessLevel]}
                    onSelectionChange={(keys) => handleInputChange('accessLevel', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="public">Public</SelectItem>
                    <SelectItem key="internal">Internal</SelectItem>
                    <SelectItem key="confidential">Confidential</SelectItem>
                    <SelectItem key="restricted">Restricted</SelectItem>
                  </Select>
                </div>

                <Textarea
                  label="Description"
                  placeholder="Brief description of the document..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  variant="bordered"
                  minRows={3}
                />

                <Input
                  label="Keywords"
                  placeholder="Comma-separated keywords for search"
                  value={formData.keywords}
                  onChange={(e) => handleInputChange('keywords', e.target.value)}
                  variant="bordered"
                />
              </CardBody>
            </Card>

            {/* Tags */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Tags</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a tag..."
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addTag()}
                    variant="bordered"
                    className="flex-1"
                    startContent={<Tag className="h-4 w-4 text-default-400" />}
                  />
                  <Button
                    color="primary"
                    onPress={addTag}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.tags.map((tag, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeTag(index)}
                      variant="flat"
                      color="primary"
                    >
                      {tag}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Status and Expiry */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Status & Expiry</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Status"
                    placeholder="Select status"
                    selectedKeys={[formData.status]}
                    onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="active">Active</SelectItem>
                    <SelectItem key="archived">Archived</SelectItem>
                    <SelectItem key="expired">Expired</SelectItem>
                  </Select>

                  <Input
                    label="Expiry Date (Optional)"
                    type="date"
                    value={formData.expiryDate}
                    onChange={(e) => handleInputChange('expiryDate', e.target.value)}
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />
                </div>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit} isLoading={isUploading}>
            {document ? 'Update Document' : 'Upload Document'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DocumentForm;