import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Card,
  CardBody,
  Chip,
  DatePicker,
  Switch
} from '@nextui-org/react';
import { Upload, Plus, X, MapPin, Users, Calendar, DollarSign } from 'lucide-react';

interface WellnessProgram {
  id: string;
  title: string;
  description: string;
  category: 'fitness' | 'mental-health' | 'nutrition' | 'wellness-challenge' | 'workshop';
  instructor: string;
  startDate: string;
  endDate: string;
  location: string;
  maxParticipants: number;
  status: 'upcoming' | 'active' | 'completed' | 'cancelled';
  image: string;
  price: number;
  tags: string[];
}

interface WellnessProgramFormProps {
  isOpen: boolean;
  onClose: () => void;
  program?: WellnessProgram | null;
  onSave: (program: Partial<WellnessProgram>) => void;
}

const WellnessProgramForm: React.FC<WellnessProgramFormProps> = ({ 
  isOpen, 
  onClose, 
  program, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    title: program?.title || '',
    description: program?.description || '',
    category: program?.category || 'fitness',
    instructor: program?.instructor || '',
    startDate: program?.startDate || '',
    endDate: program?.endDate || '',
    location: program?.location || '',
    maxParticipants: program?.maxParticipants || 20,
    status: program?.status || 'upcoming',
    image: program?.image || '',
    price: program?.price || 0,
    tags: program?.tags || [],
    duration: '',
    requirements: '',
    benefits: '',
    materials: '',
    isRecurring: false,
    recurringPattern: 'weekly',
    registrationDeadline: '',
    contactEmail: '',
    specialInstructions: ''
  });

  const [newTag, setNewTag] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string | number | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const removeTag = (index: number) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) newErrors.title = 'Program title is required';
    if (!formData.description.trim()) newErrors.description = 'Description is required';
    if (!formData.instructor.trim()) newErrors.instructor = 'Instructor name is required';
    if (!formData.startDate) newErrors.startDate = 'Start date is required';
    if (!formData.endDate) newErrors.endDate = 'End date is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    
    if (formData.startDate && formData.endDate) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      if (end < start) {
        newErrors.endDate = 'End date must be after start date';
      }
    }

    if (formData.maxParticipants <= 0) {
      newErrors.maxParticipants = 'Max participants must be greater than 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSave(formData);
      onClose();
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
      classNames={{
        base: "max-h-[90vh]",
        body: "py-6",
      }}
    >
      <ModalContent>
        <ModalHeader className="flex flex-col gap-1">
          {program ? 'Edit Wellness Program' : 'Create New Wellness Program'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Program Information</h3>
                
                {/* Image Upload */}
                <div className="flex items-center space-x-4">
                  <div className="w-32 h-20 bg-default-100 rounded-lg flex items-center justify-center overflow-hidden">
                    {formData.image ? (
                      <img src={formData.image} alt="Program" className="w-full h-full object-cover" />
                    ) : (
                      <Upload className="h-6 w-6 text-default-400" />
                    )}
                  </div>
                  <div>
                    <Button
                      variant="bordered"
                      startContent={<Upload className="h-4 w-4" />}
                      size="sm"
                    >
                      Upload Image
                    </Button>
                    <p className="text-xs text-default-500 mt-1">JPG, PNG up to 2MB (16:9 ratio recommended)</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Program Title"
                    placeholder="e.g. Morning Yoga Sessions"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    isRequired
                    errorMessage={errors.title}
                    isInvalid={!!errors.title}
                    variant="bordered"
                  />

                  <Select
                    label="Category"
                    placeholder="Select category"
                    selectedKeys={[formData.category]}
                    onSelectionChange={(keys) => handleInputChange('category', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="fitness">Fitness</SelectItem>
                    <SelectItem key="mental-health">Mental Health</SelectItem>
                    <SelectItem key="nutrition">Nutrition</SelectItem>
                    <SelectItem key="wellness-challenge">Wellness Challenge</SelectItem>
                    <SelectItem key="workshop">Workshop</SelectItem>
                  </Select>

                  <Input
                    label="Instructor/Facilitator"
                    placeholder="e.g. Sarah Chen"
                    value={formData.instructor}
                    onChange={(e) => handleInputChange('instructor', e.target.value)}
                    isRequired
                    errorMessage={errors.instructor}
                    isInvalid={!!errors.instructor}
                    variant="bordered"
                  />

                  <Input
                    label="Contact Email"
                    placeholder="instructor@company.com"
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Location"
                    placeholder="e.g. Conference Room A or Virtual"
                    value={formData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                    isRequired
                    errorMessage={errors.location}
                    isInvalid={!!errors.location}
                    variant="bordered"
                    startContent={<MapPin className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Max Participants"
                    placeholder="Maximum number of participants"
                    type="number"
                    value={formData.maxParticipants.toString()}
                    onChange={(e) => handleInputChange('maxParticipants', parseInt(e.target.value) || 0)}
                    isRequired
                    errorMessage={errors.maxParticipants}
                    isInvalid={!!errors.maxParticipants}
                    variant="bordered"
                    startContent={<Users className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Price"
                    placeholder="Program cost (0 for free)"
                    type="number"
                    value={formData.price.toString()}
                    onChange={(e) => handleInputChange('price', parseFloat(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<DollarSign className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Duration"
                    placeholder="e.g. 1 hour, 4 weeks"
                    value={formData.duration}
                    onChange={(e) => handleInputChange('duration', e.target.value)}
                    variant="bordered"
                  />
                </div>

                <Textarea
                  label="Program Description"
                  placeholder="Provide a detailed description of the wellness program..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  isRequired
                  errorMessage={errors.description}
                  isInvalid={!!errors.description}
                  variant="bordered"
                  minRows={4}
                />
              </CardBody>
            </Card>

            {/* Schedule */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Schedule</h3>
                
                <div className="flex items-center space-x-2 mb-4">
                  <Switch
                    isSelected={formData.isRecurring}
                    onValueChange={(value) => handleInputChange('isRecurring', value)}
                    size="sm"
                  />
                  <span className="text-sm">Recurring Program</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Start Date"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => handleInputChange('startDate', e.target.value)}
                    isRequired
                    errorMessage={errors.startDate}
                    isInvalid={!!errors.startDate}
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="End Date"
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => handleInputChange('endDate', e.target.value)}
                    isRequired
                    errorMessage={errors.endDate}
                    isInvalid={!!errors.endDate}
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />

                  {formData.isRecurring && (
                    <Select
                      label="Recurring Pattern"
                      placeholder="Select pattern"
                      selectedKeys={[formData.recurringPattern]}
                      onSelectionChange={(keys) => handleInputChange('recurringPattern', Array.from(keys)[0] as string)}
                      variant="bordered"
                    >
                      <SelectItem key="daily">Daily</SelectItem>
                      <SelectItem key="weekly">Weekly</SelectItem>
                      <SelectItem key="monthly">Monthly</SelectItem>
                    </Select>
                  )}

                  <Input
                    label="Registration Deadline"
                    type="date"
                    value={formData.registrationDeadline}
                    onChange={(e) => handleInputChange('registrationDeadline', e.target.value)}
                    variant="bordered"
                  />
                </div>
              </CardBody>
            </Card>

            {/* Additional Details */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Additional Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Textarea
                    label="Requirements"
                    placeholder="Any prerequisites or requirements..."
                    value={formData.requirements}
                    onChange={(e) => handleInputChange('requirements', e.target.value)}
                    variant="bordered"
                    minRows={3}
                  />

                  <Textarea
                    label="Benefits"
                    placeholder="What participants will gain..."
                    value={formData.benefits}
                    onChange={(e) => handleInputChange('benefits', e.target.value)}
                    variant="bordered"
                    minRows={3}
                  />

                  <Textarea
                    label="Materials Needed"
                    placeholder="What participants should bring..."
                    value={formData.materials}
                    onChange={(e) => handleInputChange('materials', e.target.value)}
                    variant="bordered"
                    minRows={2}
                    className="md:col-span-2"
                  />

                  <Textarea
                    label="Special Instructions"
                    placeholder="Any special notes or instructions..."
                    value={formData.specialInstructions}
                    onChange={(e) => handleInputChange('specialInstructions', e.target.value)}
                    variant="bordered"
                    minRows={2}
                    className="md:col-span-2"
                  />
                </div>
              </CardBody>
            </Card>

            {/* Tags */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Tags</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a tag..."
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addTag()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addTag}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.tags.map((tag, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeTag(index)}
                      variant="flat"
                      color="primary"
                    >
                      {tag}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Status */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Program Status</h3>
                <Select
                  label="Status"
                  placeholder="Select status"
                  selectedKeys={[formData.status]}
                  onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                  variant="bordered"
                  className="max-w-xs"
                >
                  <SelectItem key="upcoming">Upcoming</SelectItem>
                  <SelectItem key="active">Active</SelectItem>
                  <SelectItem key="completed">Completed</SelectItem>
                  <SelectItem key="cancelled">Cancelled</SelectItem>
                </Select>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {program ? 'Update Program' : 'Create Program'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default WellnessProgramForm;