import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Chip,
  Card,
  CardBody
} from '@nextui-org/react';
import { Plus, X } from 'lucide-react';
import { Job } from '../../types';

interface JobFormProps {
  isOpen: boolean;
  onClose: () => void;
  job?: Job | null;
  onSave: (job: Partial<Job>) => void;
}

const JobForm: React.FC<JobFormProps> = ({ isOpen, onClose, job, onSave }) => {
  const [formData, setFormData] = useState({
    title: job?.title || '',
    department: job?.department || '',
    location: job?.location || '',
    type: job?.type || 'full-time',
    status: job?.status || 'open',
    description: job?.description || '',
    salary: job?.salary || '',
    requirements: job?.requirements || [],
    responsibilities: [] as string[],
    benefits: [] as string[],
    experienceLevel: 'mid-level',
    reportingTo: '',
    teamSize: '',
    workArrangement: 'hybrid'
  });

  const [newRequirement, setNewRequirement] = useState('');
  const [newResponsibility, setNewResponsibility] = useState('');
  const [newBenefit, setNewBenefit] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const addRequirement = () => {
    if (newRequirement.trim()) {
      setFormData(prev => ({
        ...prev,
        requirements: [...prev.requirements, newRequirement.trim()]
      }));
      setNewRequirement('');
    }
  };

  const removeRequirement = (index: number) => {
    setFormData(prev => ({
      ...prev,
      requirements: prev.requirements.filter((_, i) => i !== index)
    }));
  };

  const addResponsibility = () => {
    if (newResponsibility.trim()) {
      setFormData(prev => ({
        ...prev,
        responsibilities: [...prev.responsibilities, newResponsibility.trim()]
      }));
      setNewResponsibility('');
    }
  };

  const removeResponsibility = (index: number) => {
    setFormData(prev => ({
      ...prev,
      responsibilities: prev.responsibilities.filter((_, i) => i !== index)
    }));
  };

  const addBenefit = () => {
    if (newBenefit.trim()) {
      setFormData(prev => ({
        ...prev,
        benefits: [...prev.benefits, newBenefit.trim()]
      }));
      setNewBenefit('');
    }
  };

  const removeBenefit = (index: number) => {
    setFormData(prev => ({
      ...prev,
      benefits: prev.benefits.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) newErrors.title = 'Job title is required';
    if (!formData.department) newErrors.department = 'Department is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.description.trim()) newErrors.description = 'Job description is required';
    if (!formData.salary.trim()) newErrors.salary = 'Salary range is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSave({
        ...formData,
        postedDate: job?.postedDate || new Date().toISOString().split('T')[0],
        applicants: job?.applicants || 0
      });
      onClose();
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
      classNames={{
        base: "max-h-[90vh]",
        body: "py-6",
      }}
    >
      <ModalContent>
        <ModalHeader className="flex flex-col gap-1">
          {job ? 'Edit Job Posting' : 'Create New Job Posting'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Basic Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Job Title"
                    placeholder="e.g. Senior Software Engineer"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    isRequired
                    errorMessage={errors.title}
                    isInvalid={!!errors.title}
                    variant="bordered"
                  />

                  <Select
                    label="Department"
                    placeholder="Select department"
                    selectedKeys={formData.department ? [formData.department] : []}
                    onSelectionChange={(keys) => handleInputChange('department', Array.from(keys)[0] as string)}
                    isRequired
                    errorMessage={errors.department}
                    isInvalid={!!errors.department}
                    variant="bordered"
                  >
                    <SelectItem key="Engineering">Engineering</SelectItem>
                    <SelectItem key="Marketing">Marketing</SelectItem>
                    <SelectItem key="Sales">Sales</SelectItem>
                    <SelectItem key="HR">Human Resources</SelectItem>
                    <SelectItem key="Finance">Finance</SelectItem>
                    <SelectItem key="Operations">Operations</SelectItem>
                    <SelectItem key="Design">Design</SelectItem>
                    <SelectItem key="Product">Product</SelectItem>
                  </Select>

                  <Input
                    label="Location"
                    placeholder="e.g. San Francisco, CA or Remote"
                    value={formData.location}
                    onChange={(e) => handleInputChange('location', e.target.value)}
                    isRequired
                    errorMessage={errors.location}
                    isInvalid={!!errors.location}
                    variant="bordered"
                  />

                  <Select
                    label="Employment Type"
                    placeholder="Select employment type"
                    selectedKeys={[formData.type]}
                    onSelectionChange={(keys) => handleInputChange('type', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="full-time">Full Time</SelectItem>
                    <SelectItem key="part-time">Part Time</SelectItem>
                    <SelectItem key="contract">Contract</SelectItem>
                    <SelectItem key="intern">Internship</SelectItem>
                  </Select>

                  <Select
                    label="Experience Level"
                    placeholder="Select experience level"
                    selectedKeys={[formData.experienceLevel]}
                    onSelectionChange={(keys) => handleInputChange('experienceLevel', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="entry-level">Entry Level</SelectItem>
                    <SelectItem key="mid-level">Mid Level</SelectItem>
                    <SelectItem key="senior-level">Senior Level</SelectItem>
                    <SelectItem key="executive">Executive</SelectItem>
                  </Select>

                  <Select
                    label="Work Arrangement"
                    placeholder="Select work arrangement"
                    selectedKeys={[formData.workArrangement]}
                    onSelectionChange={(keys) => handleInputChange('workArrangement', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="remote">Remote</SelectItem>
                    <SelectItem key="hybrid">Hybrid</SelectItem>
                    <SelectItem key="on-site">On-site</SelectItem>
                  </Select>

                  <Input
                    label="Salary Range"
                    placeholder="e.g. $80,000 - $120,000"
                    value={formData.salary}
                    onChange={(e) => handleInputChange('salary', e.target.value)}
                    isRequired
                    errorMessage={errors.salary}
                    isInvalid={!!errors.salary}
                    variant="bordered"
                  />

                  <Input
                    label="Reporting To"
                    placeholder="e.g. Engineering Manager"
                    value={formData.reportingTo}
                    onChange={(e) => handleInputChange('reportingTo', e.target.value)}
                    variant="bordered"
                  />
                </div>

                <Textarea
                  label="Job Description"
                  placeholder="Provide a detailed description of the role..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  isRequired
                  errorMessage={errors.description}
                  isInvalid={!!errors.description}
                  variant="bordered"
                  minRows={4}
                />
              </CardBody>
            </Card>

            {/* Requirements */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Requirements</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a requirement..."
                    value={newRequirement}
                    onChange={(e) => setNewRequirement(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addRequirement()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addRequirement}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.requirements.map((req, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeRequirement(index)}
                      variant="flat"
                      color="primary"
                    >
                      {req}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Responsibilities */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Key Responsibilities</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a responsibility..."
                    value={newResponsibility}
                    onChange={(e) => setNewResponsibility(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addResponsibility()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addResponsibility}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.responsibilities.map((resp, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeResponsibility(index)}
                      variant="flat"
                      color="secondary"
                    >
                      {resp}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Benefits */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Benefits & Perks</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a benefit..."
                    value={newBenefit}
                    onChange={(e) => setNewBenefit(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addBenefit()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addBenefit}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.benefits.map((benefit, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeBenefit(index)}
                      variant="flat"
                      color="success"
                    >
                      {benefit}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Status */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Posting Status</h3>
                <Select
                  label="Status"
                  placeholder="Select status"
                  selectedKeys={[formData.status]}
                  onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                  variant="bordered"
                  className="max-w-xs"
                >
                  <SelectItem key="draft">Draft</SelectItem>
                  <SelectItem key="open">Open</SelectItem>
                  <SelectItem key="closed">Closed</SelectItem>
                </Select>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {job ? 'Update Job' : 'Create Job'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default JobForm;