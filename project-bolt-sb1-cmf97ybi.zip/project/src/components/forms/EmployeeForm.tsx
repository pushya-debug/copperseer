import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  DatePicker,
  Avatar,
  Card,
  CardBody,
  Tabs,
  Tab
} from '@nextui-org/react';
import { Upload, X } from 'lucide-react';
import { Employee } from '../../types';

interface EmployeeFormProps {
  isOpen: boolean;
  onClose: () => void;
  employee?: Employee | null;
  onSave: (employee: Partial<Employee>) => void;
}

const EmployeeForm: React.FC<EmployeeFormProps> = ({ isOpen, onClose, employee, onSave }) => {
  const [formData, setFormData] = useState({
    name: employee?.name || '',
    email: employee?.email || '',
    phone: employee?.phone || '',
    department: employee?.department || '',
    position: employee?.position || '',
    manager: employee?.manager || '',
    joinDate: employee?.joinDate || '',
    status: employee?.status || 'active',
    salary: employee?.salary || 0,
    leaveBalance: employee?.leaveBalance || 25,
    avatar: employee?.avatar || '',
    address: '',
    emergencyContact: '',
    emergencyPhone: '',
    dateOfBirth: '',
    nationality: '',
    employeeId: '',
    workLocation: '',
    employmentType: 'full-time'
  });

  const [activeTab, setActiveTab] = useState('personal');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    if (!formData.department) newErrors.department = 'Department is required';
    if (!formData.position.trim()) newErrors.position = 'Position is required';
    if (!formData.joinDate) newErrors.joinDate = 'Join date is required';
    
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Invalid email format';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSave(formData);
      onClose();
    }
  };

  const handleReset = () => {
    setFormData({
      name: employee?.name || '',
      email: employee?.email || '',
      phone: employee?.phone || '',
      department: employee?.department || '',
      position: employee?.position || '',
      manager: employee?.manager || '',
      joinDate: employee?.joinDate || '',
      status: employee?.status || 'active',
      salary: employee?.salary || 0,
      leaveBalance: employee?.leaveBalance || 25,
      avatar: employee?.avatar || '',
      address: '',
      emergencyContact: '',
      emergencyPhone: '',
      dateOfBirth: '',
      nationality: '',
      employeeId: '',
      workLocation: '',
      employmentType: 'full-time'
    });
    setErrors({});
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
      classNames={{
        base: "max-h-[90vh]",
        body: "py-6",
      }}
    >
      <ModalContent>
        <ModalHeader className="flex flex-col gap-1">
          {employee ? 'Edit Employee' : 'Add New Employee'}
        </ModalHeader>
        <ModalBody>
          <Tabs 
            selectedKey={activeTab} 
            onSelectionChange={(key) => setActiveTab(key as string)}
            className="w-full"
          >
            <Tab key="personal" title="Personal Info">
              <div className="space-y-6">
                {/* Avatar Upload */}
                <div className="flex items-center space-x-4">
                  <Avatar
                    src={formData.avatar}
                    name={formData.name}
                    size="lg"
                    className="w-20 h-20"
                  />
                  <div>
                    <Button
                      variant="bordered"
                      startContent={<Upload className="h-4 w-4" />}
                      size="sm"
                    >
                      Upload Photo
                    </Button>
                    <p className="text-xs text-default-500 mt-1">JPG, PNG up to 2MB</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Full Name"
                    placeholder="Enter full name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    isRequired
                    errorMessage={errors.name}
                    isInvalid={!!errors.name}
                    variant="bordered"
                  />
                  
                  <Input
                    label="Employee ID"
                    placeholder="Enter employee ID"
                    value={formData.employeeId}
                    onChange={(e) => handleInputChange('employeeId', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Email"
                    placeholder="Enter email address"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    isRequired
                    errorMessage={errors.email}
                    isInvalid={!!errors.email}
                    variant="bordered"
                  />

                  <Input
                    label="Phone Number"
                    placeholder="Enter phone number"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    isRequired
                    errorMessage={errors.phone}
                    isInvalid={!!errors.phone}
                    variant="bordered"
                  />

                  <Input
                    label="Date of Birth"
                    placeholder="YYYY-MM-DD"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Nationality"
                    placeholder="Enter nationality"
                    value={formData.nationality}
                    onChange={(e) => handleInputChange('nationality', e.target.value)}
                    variant="bordered"
                  />

                  <Textarea
                    label="Address"
                    placeholder="Enter full address"
                    value={formData.address}
                    onChange={(e) => handleInputChange('address', e.target.value)}
                    variant="bordered"
                    className="md:col-span-2"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Emergency Contact"
                    placeholder="Emergency contact name"
                    value={formData.emergencyContact}
                    onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Emergency Phone"
                    placeholder="Emergency contact phone"
                    value={formData.emergencyPhone}
                    onChange={(e) => handleInputChange('emergencyPhone', e.target.value)}
                    variant="bordered"
                  />
                </div>
              </div>
            </Tab>

            <Tab key="job" title="Job Information">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Department"
                    placeholder="Select department"
                    selectedKeys={formData.department ? [formData.department] : []}
                    onSelectionChange={(keys) => handleInputChange('department', Array.from(keys)[0] as string)}
                    isRequired
                    errorMessage={errors.department}
                    isInvalid={!!errors.department}
                    variant="bordered"
                  >
                    <SelectItem key="Engineering">Engineering</SelectItem>
                    <SelectItem key="Marketing">Marketing</SelectItem>
                    <SelectItem key="Sales">Sales</SelectItem>
                    <SelectItem key="HR">Human Resources</SelectItem>
                    <SelectItem key="Finance">Finance</SelectItem>
                    <SelectItem key="Operations">Operations</SelectItem>
                  </Select>

                  <Input
                    label="Position/Title"
                    placeholder="Enter job title"
                    value={formData.position}
                    onChange={(e) => handleInputChange('position', e.target.value)}
                    isRequired
                    errorMessage={errors.position}
                    isInvalid={!!errors.position}
                    variant="bordered"
                  />

                  <Input
                    label="Direct Manager"
                    placeholder="Enter manager name"
                    value={formData.manager}
                    onChange={(e) => handleInputChange('manager', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Join Date"
                    type="date"
                    value={formData.joinDate}
                    onChange={(e) => handleInputChange('joinDate', e.target.value)}
                    isRequired
                    errorMessage={errors.joinDate}
                    isInvalid={!!errors.joinDate}
                    variant="bordered"
                  />

                  <Select
                    label="Employment Type"
                    placeholder="Select employment type"
                    selectedKeys={[formData.employmentType]}
                    onSelectionChange={(keys) => handleInputChange('employmentType', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="full-time">Full Time</SelectItem>
                    <SelectItem key="part-time">Part Time</SelectItem>
                    <SelectItem key="contract">Contract</SelectItem>
                    <SelectItem key="intern">Intern</SelectItem>
                  </Select>

                  <Input
                    label="Work Location"
                    placeholder="Enter work location"
                    value={formData.workLocation}
                    onChange={(e) => handleInputChange('workLocation', e.target.value)}
                    variant="bordered"
                  />

                  <Select
                    label="Status"
                    placeholder="Select status"
                    selectedKeys={[formData.status]}
                    onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="active">Active</SelectItem>
                    <SelectItem key="inactive">Inactive</SelectItem>
                    <SelectItem key="terminated">Terminated</SelectItem>
                  </Select>
                </div>
              </div>
            </Tab>

            <Tab key="compensation" title="Compensation">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Annual Salary"
                    placeholder="Enter annual salary"
                    type="number"
                    value={formData.salary.toString()}
                    onChange={(e) => handleInputChange('salary', parseInt(e.target.value) || 0)}
                    startContent={<span className="text-default-400">$</span>}
                    variant="bordered"
                  />

                  <Input
                    label="Leave Balance"
                    placeholder="Enter leave balance"
                    type="number"
                    value={formData.leaveBalance.toString()}
                    onChange={(e) => handleInputChange('leaveBalance', parseInt(e.target.value) || 0)}
                    endContent={<span className="text-default-400">days</span>}
                    variant="bordered"
                  />
                </div>

                <Card>
                  <CardBody>
                    <h4 className="font-semibold mb-4">Benefits Package</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">Health Insurance</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">Dental Insurance</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">Vision Insurance</span>
                        </label>
                      </div>
                      <div className="space-y-2">
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">401(k) Plan</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">Life Insurance</span>
                        </label>
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">Flexible Spending Account</span>
                        </label>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </div>
            </Tab>
          </Tabs>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={handleReset}>
            Reset
          </Button>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {employee ? 'Update Employee' : 'Add Employee'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default EmployeeForm;