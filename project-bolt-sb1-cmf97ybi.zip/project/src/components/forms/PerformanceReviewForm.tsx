import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Card,
  CardBody,
  Slider,
  Chip,
  Progress
} from '@nextui-org/react';
import { Star, Target, Calendar, User, Plus, X } from 'lucide-react';

interface PerformanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  position: string;
  currentRating: number;
  goals: {
    total: number;
    completed: number;
    inProgress: number;
  };
  lastReview: string;
  nextReview: string;
  status: 'excellent' | 'good' | 'needs-improvement' | 'poor';
}

interface PerformanceReviewFormProps {
  isOpen: boolean;
  onClose: () => void;
  record?: PerformanceRecord | null;
  onSave: (review: any) => void;
}

const PerformanceReviewForm: React.FC<PerformanceReviewFormProps> = ({ 
  isOpen, 
  onClose, 
  record, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    employeeName: record?.employeeName || '',
    employeeId: record?.employeeId || '',
    department: record?.department || '',
    position: record?.position || '',
    reviewPeriod: '',
    reviewType: 'annual',
    overallRating: record?.currentRating || 3,
    
    // Performance areas
    jobKnowledge: 3,
    qualityOfWork: 3,
    productivity: 3,
    communication: 3,
    teamwork: 3,
    leadership: 3,
    problemSolving: 3,
    initiative: 3,
    
    // Goals and achievements
    goals: [] as { id: string; description: string; status: 'completed' | 'in-progress' | 'not-started'; priority: 'high' | 'medium' | 'low' }[],
    achievements: '',
    areasForImprovement: '',
    developmentPlan: '',
    managerComments: '',
    employeeComments: '',
    
    // Next review
    nextReviewDate: '',
    recommendedActions: [] as string[]
  });

  const [newGoal, setNewGoal] = useState({
    description: '',
    priority: 'medium' as const
  });

  const [newAction, setNewAction] = useState('');

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addGoal = () => {
    if (newGoal.description.trim()) {
      const goal = {
        id: Date.now().toString(),
        description: newGoal.description.trim(),
        status: 'not-started' as const,
        priority: newGoal.priority
      };
      
      setFormData(prev => ({
        ...prev,
        goals: [...prev.goals, goal]
      }));
      
      setNewGoal({ description: '', priority: 'medium' });
    }
  };

  const removeGoal = (goalId: string) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.filter(goal => goal.id !== goalId)
    }));
  };

  const addAction = () => {
    if (newAction.trim()) {
      setFormData(prev => ({
        ...prev,
        recommendedActions: [...prev.recommendedActions, newAction.trim()]
      }));
      setNewAction('');
    }
  };

  const removeAction = (index: number) => {
    setFormData(prev => ({
      ...prev,
      recommendedActions: prev.recommendedActions.filter((_, i) => i !== index)
    }));
  };

  const calculateOverallRating = () => {
    const ratings = [
      formData.jobKnowledge,
      formData.qualityOfWork,
      formData.productivity,
      formData.communication,
      formData.teamwork,
      formData.leadership,
      formData.problemSolving,
      formData.initiative
    ];
    
    return ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length;
  };

  const handleSubmit = () => {
    const overallRating = calculateOverallRating();
    onSave({
      ...formData,
      overallRating,
      reviewDate: new Date().toISOString().split('T')[0]
    });
    onClose();
  };

  const getRatingColor = (rating: number) => {
    if (rating >= 4.5) return 'success';
    if (rating >= 4.0) return 'primary';
    if (rating >= 3.0) return 'warning';
    return 'danger';
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'danger';
      case 'medium': return 'warning';
      case 'low': return 'success';
      default: return 'default';
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="5xl"
      scrollBehavior="inside"
      classNames={{
        base: "max-h-[90vh]",
        body: "py-6",
      }}
    >
      <ModalContent>
        <ModalHeader>
          {record ? 'Performance Review' : 'Schedule Performance Review'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Employee Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Employee Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Employee Name"
                    value={formData.employeeName}
                    onChange={(e) => handleInputChange('employeeName', e.target.value)}
                    variant="bordered"
                    startContent={<User className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Employee ID"
                    value={formData.employeeId}
                    onChange={(e) => handleInputChange('employeeId', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Department"
                    value={formData.department}
                    onChange={(e) => handleInputChange('department', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Position"
                    value={formData.position}
                    onChange={(e) => handleInputChange('position', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Review Period"
                    placeholder="e.g. Q4 2023"
                    value={formData.reviewPeriod}
                    onChange={(e) => handleInputChange('reviewPeriod', e.target.value)}
                    variant="bordered"
                  />

                  <Select
                    label="Review Type"
                    selectedKeys={[formData.reviewType]}
                    onSelectionChange={(keys) => handleInputChange('reviewType', Array.from(keys)[0])}
                    variant="bordered"
                  >
                    <SelectItem key="annual">Annual Review</SelectItem>
                    <SelectItem key="quarterly">Quarterly Review</SelectItem>
                    <SelectItem key="probationary">Probationary Review</SelectItem>
                    <SelectItem key="promotion">Promotion Review</SelectItem>
                  </Select>
                </div>
              </CardBody>
            </Card>

            {/* Performance Ratings */}
            <Card>
              <CardBody className="space-y-6">
                <h3 className="text-lg font-semibold">Performance Evaluation</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Job Knowledge</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.jobKnowledge}
                        onChange={(value) => handleInputChange('jobKnowledge', value)}
                        color={getRatingColor(formData.jobKnowledge)}
                        className="max-w-md"
                      />
                      <div className="flex justify-between text-xs text-default-500 mt-1">
                        <span>Poor</span>
                        <span>Excellent</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Quality of Work</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.qualityOfWork}
                        onChange={(value) => handleInputChange('qualityOfWork', value)}
                        color={getRatingColor(formData.qualityOfWork)}
                        className="max-w-md"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Productivity</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.productivity}
                        onChange={(value) => handleInputChange('productivity', value)}
                        color={getRatingColor(formData.productivity)}
                        className="max-w-md"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Communication</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.communication}
                        onChange={(value) => handleInputChange('communication', value)}
                        color={getRatingColor(formData.communication)}
                        className="max-w-md"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Teamwork</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.teamwork}
                        onChange={(value) => handleInputChange('teamwork', value)}
                        color={getRatingColor(formData.teamwork)}
                        className="max-w-md"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Leadership</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.leadership}
                        onChange={(value) => handleInputChange('leadership', value)}
                        color={getRatingColor(formData.leadership)}
                        className="max-w-md"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Problem Solving</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.problemSolving}
                        onChange={(value) => handleInputChange('problemSolving', value)}
                        color={getRatingColor(formData.problemSolving)}
                        className="max-w-md"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Initiative</label>
                      <Slider
                        step={0.5}
                        minValue={1}
                        maxValue={5}
                        value={formData.initiative}
                        onChange={(value) => handleInputChange('initiative', value)}
                        color={getRatingColor(formData.initiative)}
                        className="max-w-md"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-primary/10 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">Overall Rating:</span>
                    <div className="flex items-center space-x-2">
                      <Progress 
                        value={(calculateOverallRating() / 5) * 100} 
                        color={getRatingColor(calculateOverallRating())} 
                        size="sm" 
                        className="w-32" 
                      />
                      <span className="text-xl font-bold">{calculateOverallRating().toFixed(1)}/5</span>
                    </div>
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Goals and Achievements */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Goals & Achievements</h3>
                
                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add a goal..."
                      value={newGoal.description}
                      onChange={(e) => setNewGoal(prev => ({ ...prev, description: e.target.value }))}
                      variant="bordered"
                      className="flex-1"
                    />
                    <Select
                      placeholder="Priority"
                      selectedKeys={[newGoal.priority]}
                      onSelectionChange={(keys) => setNewGoal(prev => ({ ...prev, priority: Array.from(keys)[0] as any }))}
                      variant="bordered"
                      className="w-32"
                    >
                      <SelectItem key="high">High</SelectItem>
                      <SelectItem key="medium">Medium</SelectItem>
                      <SelectItem key="low">Low</SelectItem>
                    </Select>
                    <Button
                      color="primary"
                      onPress={addGoal}
                      startContent={<Plus className="h-4 w-4" />}
                    >
                      Add
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {formData.goals.map((goal) => (
                      <div key={goal.id} className="flex items-center justify-between p-3 border border-default-200 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Target className="h-4 w-4 text-default-400" />
                          <span>{goal.description}</span>
                          <Chip 
                            size="sm" 
                            color={getPriorityColor(goal.priority)} 
                            variant="flat"
                          >
                            {goal.priority}
                          </Chip>
                        </div>
                        <Button
                          isIconOnly
                          variant="light"
                          color="danger"
                          onPress={() => removeGoal(goal.id)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                <Textarea
                  label="Key Achievements"
                  placeholder="Describe the employee's key achievements during this period..."
                  value={formData.achievements}
                  onChange={(e) => handleInputChange('achievements', e.target.value)}
                  variant="bordered"
                  minRows={3}
                />

                <Textarea
                  label="Areas for Improvement"
                  placeholder="Identify areas where the employee can improve..."
                  value={formData.areasForImprovement}
                  onChange={(e) => handleInputChange('areasForImprovement', e.target.value)}
                  variant="bordered"
                  minRows={3}
                />
              </CardBody>
            </Card>

            {/* Development Plan */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Development Plan</h3>
                
                <Textarea
                  label="Development Plan"
                  placeholder="Outline the development plan for the next period..."
                  value={formData.developmentPlan}
                  onChange={(e) => handleInputChange('developmentPlan', e.target.value)}
                  variant="bordered"
                  minRows={4}
                />

                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add recommended action..."
                      value={newAction}
                      onChange={(e) => setNewAction(e.target.value)}
                      variant="bordered"
                      className="flex-1"
                    />
                    <Button
                      color="primary"
                      onPress={addAction}
                      startContent={<Plus className="h-4 w-4" />}
                    >
                      Add
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {formData.recommendedActions.map((action, index) => (
                      <Chip
                        key={index}
                        onClose={() => removeAction(index)}
                        variant="flat"
                        color="primary"
                      >
                        {action}
                      </Chip>
                    ))}
                  </div>
                </div>

                <Input
                  label="Next Review Date"
                  type="date"
                  value={formData.nextReviewDate}
                  onChange={(e) => handleInputChange('nextReviewDate', e.target.value)}
                  variant="bordered"
                  startContent={<Calendar className="h-4 w-4 text-default-400" />}
                />
              </CardBody>
            </Card>

            {/* Comments */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Comments</h3>
                
                <Textarea
                  label="Manager Comments"
                  placeholder="Additional comments from the manager..."
                  value={formData.managerComments}
                  onChange={(e) => handleInputChange('managerComments', e.target.value)}
                  variant="bordered"
                  minRows={3}
                />

                <Textarea
                  label="Employee Comments"
                  placeholder="Employee's self-assessment and comments..."
                  value={formData.employeeComments}
                  onChange={(e) => handleInputChange('employeeComments', e.target.value)}
                  variant="bordered"
                  minRows={3}
                />
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            Save Review
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default PerformanceReviewForm;