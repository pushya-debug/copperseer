import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Card,
  CardBody,
  Chip,
  Checkbox,
  DatePicker
} from '@nextui-org/react';
import { BarChart3, Calendar, Filter, Plus, X } from 'lucide-react';

interface Report {
  id: string;
  name: string;
  description: string;
  category: 'hr' | 'payroll' | 'performance' | 'attendance' | 'recruitment';
  type: 'standard' | 'custom';
  lastGenerated: string;
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
  status: 'active' | 'scheduled' | 'draft';
}

interface ReportFormProps {
  isOpen: boolean;
  onClose: () => void;
  report?: Report | null;
  onSave: (report: Partial<Report>) => void;
}

const ReportForm: React.FC<ReportFormProps> = ({ 
  isOpen, 
  onClose, 
  report, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    name: report?.name || '',
    description: report?.description || '',
    category: report?.category || 'hr',
    type: report?.type || 'custom',
    frequency: report?.frequency || 'monthly',
    status: report?.status || 'draft',
    
    // Report configuration
    dateRange: 'last-30-days',
    departments: [] as string[],
    includeCharts: true,
    includeDetails: true,
    format: 'pdf',
    recipients: [] as string[],
    scheduleTime: '09:00',
    
    // Data filters
    employeeStatus: 'all',
    includeTerminated: false,
    minSalary: '',
    maxSalary: '',
    
    // Custom fields
    customFields: [] as string[],
    groupBy: 'department',
    sortBy: 'name',
    sortOrder: 'asc'
  });

  const [newRecipient, setNewRecipient] = useState('');
  const [newField, setNewField] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const addRecipient = () => {
    if (newRecipient.trim() && !formData.recipients.includes(newRecipient.trim())) {
      setFormData(prev => ({
        ...prev,
        recipients: [...prev.recipients, newRecipient.trim()]
      }));
      setNewRecipient('');
    }
  };

  const removeRecipient = (index: number) => {
    setFormData(prev => ({
      ...prev,
      recipients: prev.recipients.filter((_, i) => i !== index)
    }));
  };

  const addCustomField = () => {
    if (newField.trim() && !formData.customFields.includes(newField.trim())) {
      setFormData(prev => ({
        ...prev,
        customFields: [...prev.customFields, newField.trim()]
      }));
      setNewField('');
    }
  };

  const removeCustomField = (index: number) => {
    setFormData(prev => ({
      ...prev,
      customFields: prev.customFields.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) newErrors.name = 'Report name is required';
    if (!formData.description.trim()) newErrors.description = 'Description is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSave({
        ...formData,
        lastGenerated: report?.lastGenerated || new Date().toISOString().split('T')[0]
      });
      onClose();
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'hr': return 'primary';
      case 'payroll': return 'success';
      case 'performance': return 'warning';
      case 'attendance': return 'secondary';
      case 'recruitment': return 'danger';
      default: return 'default';
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
    >
      <ModalContent>
        <ModalHeader>
          {report ? 'Edit Report' : 'Create New Report'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Report Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Report Name"
                    placeholder="e.g. Monthly Employee Report"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    isRequired
                    errorMessage={errors.name}
                    isInvalid={!!errors.name}
                    variant="bordered"
                  />

                  <Select
                    label="Category"
                    placeholder="Select category"
                    selectedKeys={[formData.category]}
                    onSelectionChange={(keys) => handleInputChange('category', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="hr">HR</SelectItem>
                    <SelectItem key="payroll">Payroll</SelectItem>
                    <SelectItem key="performance">Performance</SelectItem>
                    <SelectItem key="attendance">Attendance</SelectItem>
                    <SelectItem key="recruitment">Recruitment</SelectItem>
                  </Select>

                  <Select
                    label="Report Type"
                    placeholder="Select type"
                    selectedKeys={[formData.type]}
                    onSelectionChange={(keys) => handleInputChange('type', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="standard">Standard</SelectItem>
                    <SelectItem key="custom">Custom</SelectItem>
                  </Select>

                  <Select
                    label="Frequency"
                    placeholder="Select frequency"
                    selectedKeys={[formData.frequency]}
                    onSelectionChange={(keys) => handleInputChange('frequency', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="daily">Daily</SelectItem>
                    <SelectItem key="weekly">Weekly</SelectItem>
                    <SelectItem key="monthly">Monthly</SelectItem>
                    <SelectItem key="quarterly">Quarterly</SelectItem>
                    <SelectItem key="yearly">Yearly</SelectItem>
                  </Select>
                </div>

                <Textarea
                  label="Description"
                  placeholder="Describe what this report will contain..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  isRequired
                  errorMessage={errors.description}
                  isInvalid={!!errors.description}
                  variant="bordered"
                  minRows={3}
                />
              </CardBody>
            </Card>

            {/* Data Configuration */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Data Configuration</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Date Range"
                    placeholder="Select date range"
                    selectedKeys={[formData.dateRange]}
                    onSelectionChange={(keys) => handleInputChange('dateRange', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="last-7-days">Last 7 days</SelectItem>
                    <SelectItem key="last-30-days">Last 30 days</SelectItem>
                    <SelectItem key="last-90-days">Last 90 days</SelectItem>
                    <SelectItem key="current-month">Current month</SelectItem>
                    <SelectItem key="current-quarter">Current quarter</SelectItem>
                    <SelectItem key="current-year">Current year</SelectItem>
                    <SelectItem key="custom">Custom range</SelectItem>
                  </Select>

                  <Select
                    label="Employee Status"
                    placeholder="Select employee status"
                    selectedKeys={[formData.employeeStatus]}
                    onSelectionChange={(keys) => handleInputChange('employeeStatus', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="all">All employees</SelectItem>
                    <SelectItem key="active">Active only</SelectItem>
                    <SelectItem key="inactive">Inactive only</SelectItem>
                  </Select>

                  <Input
                    label="Minimum Salary"
                    placeholder="Optional filter"
                    type="number"
                    value={formData.minSalary}
                    onChange={(e) => handleInputChange('minSalary', e.target.value)}
                    variant="bordered"
                    startContent="$"
                  />

                  <Input
                    label="Maximum Salary"
                    placeholder="Optional filter"
                    type="number"
                    value={formData.maxSalary}
                    onChange={(e) => handleInputChange('maxSalary', e.target.value)}
                    variant="bordered"
                    startContent="$"
                  />

                  <Select
                    label="Group By"
                    placeholder="Select grouping"
                    selectedKeys={[formData.groupBy]}
                    onSelectionChange={(keys) => handleInputChange('groupBy', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="department">Department</SelectItem>
                    <SelectItem key="position">Position</SelectItem>
                    <SelectItem key="manager">Manager</SelectItem>
                    <SelectItem key="location">Location</SelectItem>
                  </Select>

                  <Select
                    label="Sort By"
                    placeholder="Select sorting"
                    selectedKeys={[formData.sortBy]}
                    onSelectionChange={(keys) => handleInputChange('sortBy', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="name">Name</SelectItem>
                    <SelectItem key="department">Department</SelectItem>
                    <SelectItem key="salary">Salary</SelectItem>
                    <SelectItem key="join-date">Join Date</SelectItem>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Checkbox
                    isSelected={formData.includeTerminated}
                    onValueChange={(value) => handleInputChange('includeTerminated', value)}
                  >
                    Include terminated employees
                  </Checkbox>
                  <Checkbox
                    isSelected={formData.includeCharts}
                    onValueChange={(value) => handleInputChange('includeCharts', value)}
                  >
                    Include charts and visualizations
                  </Checkbox>
                  <Checkbox
                    isSelected={formData.includeDetails}
                    onValueChange={(value) => handleInputChange('includeDetails', value)}
                  >
                    Include detailed employee information
                  </Checkbox>
                </div>
              </CardBody>
            </Card>

            {/* Custom Fields */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Custom Fields</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add custom field..."
                    value={newField}
                    onChange={(e) => setNewField(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addCustomField()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addCustomField}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.customFields.map((field, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeCustomField(index)}
                      variant="flat"
                      color="primary"
                    >
                      {field}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Output Configuration */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Output & Delivery</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Output Format"
                    placeholder="Select format"
                    selectedKeys={[formData.format]}
                    onSelectionChange={(keys) => handleInputChange('format', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="pdf">PDF</SelectItem>
                    <SelectItem key="excel">Excel</SelectItem>
                    <SelectItem key="csv">CSV</SelectItem>
                    <SelectItem key="html">HTML</SelectItem>
                  </Select>

                  <Input
                    label="Schedule Time"
                    type="time"
                    value={formData.scheduleTime}
                    onChange={(e) => handleInputChange('scheduleTime', e.target.value)}
                    variant="bordered"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add email recipient..."
                      value={newRecipient}
                      onChange={(e) => setNewRecipient(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addRecipient()}
                      variant="bordered"
                      className="flex-1"
                    />
                    <Button
                      color="primary"
                      onPress={addRecipient}
                      startContent={<Plus className="h-4 w-4" />}
                    >
                      Add
                    </Button>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {formData.recipients.map((recipient, index) => (
                      <Chip
                        key={index}
                        onClose={() => removeRecipient(index)}
                        variant="flat"
                        color="secondary"
                      >
                        {recipient}
                      </Chip>
                    ))}
                  </div>
                </div>
              </CardBody>
            </Card>

            {/* Status */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Report Status</h3>
                <Select
                  label="Status"
                  placeholder="Select status"
                  selectedKeys={[formData.status]}
                  onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                  variant="bordered"
                  className="max-w-xs"
                >
                  <SelectItem key="draft">Draft</SelectItem>
                  <SelectItem key="active">Active</SelectItem>
                  <SelectItem key="scheduled">Scheduled</SelectItem>
                </Select>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {report ? 'Update Report' : 'Create Report'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default ReportForm;