import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Card,
  CardBody,
  Chip,
  Avatar
} from '@nextui-org/react';
import { Upload, Plus, X, Clock, Users, Award } from 'lucide-react';

interface TrainingCourse {
  id: string;
  title: string;
  description: string;
  instructor: string;
  duration: string;
  category: 'technical' | 'soft-skills' | 'compliance' | 'leadership';
  level: 'beginner' | 'intermediate' | 'advanced';
  status: 'active' | 'draft' | 'archived';
  thumbnail: string;
  maxEnrollments?: number;
  prerequisites?: string[];
  learningObjectives?: string[];
  materials?: string[];
}

interface TrainingCourseFormProps {
  isOpen: boolean;
  onClose: () => void;
  course?: TrainingCourse | null;
  onSave: (course: Partial<TrainingCourse>) => void;
}

const TrainingCourseForm: React.FC<TrainingCourseFormProps> = ({ 
  isOpen, 
  onClose, 
  course, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    title: course?.title || '',
    description: course?.description || '',
    instructor: course?.instructor || '',
    duration: course?.duration || '',
    category: course?.category || 'technical',
    level: course?.level || 'beginner',
    status: course?.status || 'draft',
    thumbnail: course?.thumbnail || '',
    maxEnrollments: course?.maxEnrollments || 50,
    prerequisites: course?.prerequisites || [],
    learningObjectives: course?.learningObjectives || [],
    materials: course?.materials || [],
    price: '',
    certificateTemplate: '',
    passingScore: 80,
    estimatedHours: '',
    language: 'english'
  });

  const [newPrerequisite, setNewPrerequisite] = useState('');
  const [newObjective, setNewObjective] = useState('');
  const [newMaterial, setNewMaterial] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const addPrerequisite = () => {
    if (newPrerequisite.trim()) {
      setFormData(prev => ({
        ...prev,
        prerequisites: [...prev.prerequisites, newPrerequisite.trim()]
      }));
      setNewPrerequisite('');
    }
  };

  const removePrerequisite = (index: number) => {
    setFormData(prev => ({
      ...prev,
      prerequisites: prev.prerequisites.filter((_, i) => i !== index)
    }));
  };

  const addObjective = () => {
    if (newObjective.trim()) {
      setFormData(prev => ({
        ...prev,
        learningObjectives: [...prev.learningObjectives, newObjective.trim()]
      }));
      setNewObjective('');
    }
  };

  const removeObjective = (index: number) => {
    setFormData(prev => ({
      ...prev,
      learningObjectives: prev.learningObjectives.filter((_, i) => i !== index)
    }));
  };

  const addMaterial = () => {
    if (newMaterial.trim()) {
      setFormData(prev => ({
        ...prev,
        materials: [...prev.materials, newMaterial.trim()]
      }));
      setNewMaterial('');
    }
  };

  const removeMaterial = (index: number) => {
    setFormData(prev => ({
      ...prev,
      materials: prev.materials.filter((_, i) => i !== index)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title.trim()) newErrors.title = 'Course title is required';
    if (!formData.description.trim()) newErrors.description = 'Description is required';
    if (!formData.instructor.trim()) newErrors.instructor = 'Instructor name is required';
    if (!formData.duration.trim()) newErrors.duration = 'Duration is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      onSave(formData);
      onClose();
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
      classNames={{
        base: "max-h-[90vh]",
        body: "py-6",
      }}
    >
      <ModalContent>
        <ModalHeader className="flex flex-col gap-1">
          {course ? 'Edit Training Course' : 'Create New Training Course'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Course Information</h3>
                
                {/* Thumbnail Upload */}
                <div className="flex items-center space-x-4">
                  <div className="w-24 h-16 bg-default-100 rounded-lg flex items-center justify-center overflow-hidden">
                    {formData.thumbnail ? (
                      <img src={formData.thumbnail} alt="Thumbnail" className="w-full h-full object-cover" />
                    ) : (
                      <Upload className="h-6 w-6 text-default-400" />
                    )}
                  </div>
                  <div>
                    <Button
                      variant="bordered"
                      startContent={<Upload className="h-4 w-4" />}
                      size="sm"
                    >
                      Upload Thumbnail
                    </Button>
                    <p className="text-xs text-default-500 mt-1">JPG, PNG up to 2MB (16:9 ratio recommended)</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Course Title"
                    placeholder="e.g. Advanced React Patterns"
                    value={formData.title}
                    onChange={(e) => handleInputChange('title', e.target.value)}
                    isRequired
                    errorMessage={errors.title}
                    isInvalid={!!errors.title}
                    variant="bordered"
                  />

                  <Input
                    label="Instructor Name"
                    placeholder="e.g. John Smith"
                    value={formData.instructor}
                    onChange={(e) => handleInputChange('instructor', e.target.value)}
                    isRequired
                    errorMessage={errors.instructor}
                    isInvalid={!!errors.instructor}
                    variant="bordered"
                  />

                  <Select
                    label="Category"
                    placeholder="Select category"
                    selectedKeys={[formData.category]}
                    onSelectionChange={(keys) => handleInputChange('category', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="technical">Technical</SelectItem>
                    <SelectItem key="soft-skills">Soft Skills</SelectItem>
                    <SelectItem key="compliance">Compliance</SelectItem>
                    <SelectItem key="leadership">Leadership</SelectItem>
                  </Select>

                  <Select
                    label="Difficulty Level"
                    placeholder="Select level"
                    selectedKeys={[formData.level]}
                    onSelectionChange={(keys) => handleInputChange('level', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="beginner">Beginner</SelectItem>
                    <SelectItem key="intermediate">Intermediate</SelectItem>
                    <SelectItem key="advanced">Advanced</SelectItem>
                  </Select>

                  <Input
                    label="Duration"
                    placeholder="e.g. 8 hours or 2 weeks"
                    value={formData.duration}
                    onChange={(e) => handleInputChange('duration', e.target.value)}
                    isRequired
                    errorMessage={errors.duration}
                    isInvalid={!!errors.duration}
                    variant="bordered"
                    startContent={<Clock className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Max Enrollments"
                    placeholder="Maximum number of students"
                    type="number"
                    value={formData.maxEnrollments.toString()}
                    onChange={(e) => handleInputChange('maxEnrollments', parseInt(e.target.value) || 0)}
                    variant="bordered"
                    startContent={<Users className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Passing Score"
                    placeholder="Minimum score to pass"
                    type="number"
                    value={formData.passingScore.toString()}
                    onChange={(e) => handleInputChange('passingScore', parseInt(e.target.value) || 0)}
                    variant="bordered"
                    endContent={<span className="text-default-400">%</span>}
                  />

                  <Select
                    label="Language"
                    placeholder="Select language"
                    selectedKeys={[formData.language]}
                    onSelectionChange={(keys) => handleInputChange('language', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="english">English</SelectItem>
                    <SelectItem key="spanish">Spanish</SelectItem>
                    <SelectItem key="french">French</SelectItem>
                    <SelectItem key="german">German</SelectItem>
                  </Select>
                </div>

                <Textarea
                  label="Course Description"
                  placeholder="Provide a detailed description of what students will learn..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  isRequired
                  errorMessage={errors.description}
                  isInvalid={!!errors.description}
                  variant="bordered"
                  minRows={4}
                />
              </CardBody>
            </Card>

            {/* Prerequisites */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Prerequisites</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a prerequisite..."
                    value={newPrerequisite}
                    onChange={(e) => setNewPrerequisite(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addPrerequisite()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addPrerequisite}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.prerequisites.map((prereq, index) => (
                    <Chip
                      key={index}
                      onClose={() => removePrerequisite(index)}
                      variant="flat"
                      color="warning"
                    >
                      {prereq}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Learning Objectives */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Learning Objectives</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add a learning objective..."
                    value={newObjective}
                    onChange={(e) => setNewObjective(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addObjective()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addObjective}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.learningObjectives.map((objective, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeObjective(index)}
                      variant="flat"
                      color="success"
                    >
                      {objective}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Course Materials */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Course Materials</h3>
                
                <div className="flex space-x-2">
                  <Input
                    placeholder="Add course material or resource..."
                    value={newMaterial}
                    onChange={(e) => setNewMaterial(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addMaterial()}
                    variant="bordered"
                    className="flex-1"
                  />
                  <Button
                    color="primary"
                    onPress={addMaterial}
                    startContent={<Plus className="h-4 w-4" />}
                  >
                    Add
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {formData.materials.map((material, index) => (
                    <Chip
                      key={index}
                      onClose={() => removeMaterial(index)}
                      variant="flat"
                      color="primary"
                    >
                      {material}
                    </Chip>
                  ))}
                </div>
              </CardBody>
            </Card>

            {/* Status and Publishing */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Publishing Settings</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select
                    label="Status"
                    placeholder="Select status"
                    selectedKeys={[formData.status]}
                    onSelectionChange={(keys) => handleInputChange('status', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="draft">Draft</SelectItem>
                    <SelectItem key="active">Active</SelectItem>
                    <SelectItem key="archived">Archived</SelectItem>
                  </Select>

                  <Input
                    label="Price (Optional)"
                    placeholder="Course price"
                    value={formData.price}
                    onChange={(e) => handleInputChange('price', e.target.value)}
                    variant="bordered"
                    startContent={<span className="text-default-400">$</span>}
                  />
                </div>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {course ? 'Update Course' : 'Create Course'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default TrainingCourseForm;