import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  DatePicker,
  Card,
  CardBody,
  Chip
} from '@nextui-org/react';
import { Calendar, Clock, FileText } from 'lucide-react';
import { LeaveRequest } from '../../types';

interface LeaveRequestFormProps {
  isOpen: boolean;
  onClose: () => void;
  leaveRequest?: LeaveRequest | null;
  onSave: (request: Partial<LeaveRequest>) => void;
}

const LeaveRequestForm: React.FC<LeaveRequestFormProps> = ({ 
  isOpen, 
  onClose, 
  leaveRequest, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    employeeName: leaveRequest?.employeeName || 'Current User',
    type: leaveRequest?.type || 'vacation',
    startDate: leaveRequest?.startDate || '',
    endDate: leaveRequest?.endDate || '',
    reason: leaveRequest?.reason || '',
    status: leaveRequest?.status || 'pending',
    halfDay: false,
    emergencyContact: '',
    workHandover: '',
    attachments: [] as File[]
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const leaveTypes = [
    { key: 'vacation', label: 'Vacation', color: 'primary' },
    { key: 'sick', label: 'Sick Leave', color: 'danger' },
    { key: 'personal', label: 'Personal Leave', color: 'secondary' },
    { key: 'maternity', label: 'Maternity Leave', color: 'success' },
    { key: 'paternity', label: 'Paternity Leave', color: 'success' },
    { key: 'bereavement', label: 'Bereavement', color: 'default' },
    { key: 'emergency', label: 'Emergency Leave', color: 'warning' }
  ];

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const calculateDays = () => {
    if (formData.startDate && formData.endDate) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      const diffTime = Math.abs(end.getTime() - start.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
      return formData.halfDay ? 0.5 : diffDays;
    }
    return 0;
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.type) newErrors.type = 'Leave type is required';
    if (!formData.startDate) newErrors.startDate = 'Start date is required';
    if (!formData.endDate) newErrors.endDate = 'End date is required';
    if (!formData.reason.trim()) newErrors.reason = 'Reason is required';
    
    if (formData.startDate && formData.endDate) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      if (end < start) {
        newErrors.endDate = 'End date must be after start date';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      const days = calculateDays();
      onSave({
        ...formData,
        days,
        appliedDate: leaveRequest?.appliedDate || new Date().toISOString().split('T')[0],
        employeeId: leaveRequest?.employeeId || '1'
      });
      onClose();
    }
  };

  const selectedLeaveType = leaveTypes.find(type => type.key === formData.type);

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="3xl"
      scrollBehavior="inside"
    >
      <ModalContent>
        <ModalHeader className="flex flex-col gap-1">
          {leaveRequest ? 'Edit Leave Request' : 'Submit Leave Request'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Leave Type Selection */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Leave Type</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {leaveTypes.map((type) => (
                    <div
                      key={type.key}
                      className={`p-3 border-2 rounded-lg cursor-pointer transition-all ${
                        formData.type === type.key
                          ? 'border-primary bg-primary/10'
                          : 'border-default-200 hover:border-default-300'
                      }`}
                      onClick={() => handleInputChange('type', type.key)}
                    >
                      <div className="text-center">
                        <Chip
                          color={type.color as any}
                          variant="flat"
                          size="sm"
                          className="mb-2"
                        >
                          {type.label}
                        </Chip>
                      </div>
                    </div>
                  ))}
                </div>
                {errors.type && (
                  <p className="text-danger text-sm mt-2">{errors.type}</p>
                )}
              </CardBody>
            </Card>

            {/* Date Selection */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Duration</h3>
                
                <div className="space-y-4">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.halfDay}
                      onChange={(e) => handleInputChange('halfDay', e.target.checked)}
                      className="rounded"
                    />
                    <span className="text-sm">Half Day Leave</span>
                  </label>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      label="Start Date"
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => handleInputChange('startDate', e.target.value)}
                      isRequired
                      errorMessage={errors.startDate}
                      isInvalid={!!errors.startDate}
                      variant="bordered"
                      startContent={<Calendar className="h-4 w-4 text-default-400" />}
                    />

                    <Input
                      label="End Date"
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => handleInputChange('endDate', e.target.value)}
                      isRequired
                      errorMessage={errors.endDate}
                      isInvalid={!!errors.endDate}
                      variant="bordered"
                      startContent={<Calendar className="h-4 w-4 text-default-400" />}
                      isDisabled={formData.halfDay}
                    />
                  </div>

                  {formData.startDate && formData.endDate && (
                    <div className="flex items-center space-x-2 p-3 bg-primary/10 rounded-lg">
                      <Clock className="h-4 w-4 text-primary" />
                      <span className="text-sm">
                        Total Duration: <strong>{calculateDays()} day{calculateDays() !== 1 ? 's' : ''}</strong>
                      </span>
                    </div>
                  )}
                </div>
              </CardBody>
            </Card>

            {/* Reason and Details */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Details</h3>
                
                <Textarea
                  label="Reason for Leave"
                  placeholder="Please provide a detailed reason for your leave request..."
                  value={formData.reason}
                  onChange={(e) => handleInputChange('reason', e.target.value)}
                  isRequired
                  errorMessage={errors.reason}
                  isInvalid={!!errors.reason}
                  variant="bordered"
                  minRows={3}
                />

                <Input
                  label="Emergency Contact"
                  placeholder="Name and phone number"
                  value={formData.emergencyContact}
                  onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                  variant="bordered"
                />

                <Textarea
                  label="Work Handover Notes"
                  placeholder="Describe how your work will be handled during your absence..."
                  value={formData.workHandover}
                  onChange={(e) => handleInputChange('workHandover', e.target.value)}
                  variant="bordered"
                  minRows={2}
                />
              </CardBody>
            </Card>

            {/* Attachments */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Supporting Documents</h3>
                <div className="border-2 border-dashed border-default-300 rounded-lg p-6 text-center">
                  <FileText className="h-8 w-8 text-default-400 mx-auto mb-2" />
                  <p className="text-sm text-default-500 mb-2">
                    Upload medical certificates, travel documents, or other supporting files
                  </p>
                  <Button variant="bordered" size="sm">
                    Choose Files
                  </Button>
                  <p className="text-xs text-default-400 mt-2">
                    PDF, JPG, PNG up to 5MB each
                  </p>
                </div>
              </CardBody>
            </Card>

            {/* Leave Balance Info */}
            <Card>
              <CardBody>
                <h3 className="text-lg font-semibold mb-4">Leave Balance</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-success/10 rounded-lg">
                    <p className="text-2xl font-bold text-success">18</p>
                    <p className="text-sm text-default-600">Vacation Days</p>
                  </div>
                  <div className="text-center p-3 bg-warning/10 rounded-lg">
                    <p className="text-2xl font-bold text-warning">5</p>
                    <p className="text-sm text-default-600">Sick Days</p>
                  </div>
                  <div className="text-center p-3 bg-secondary/10 rounded-lg">
                    <p className="text-2xl font-bold text-secondary">3</p>
                    <p className="text-sm text-default-600">Personal Days</p>
                  </div>
                  <div className="text-center p-3 bg-primary/10 rounded-lg">
                    <p className="text-2xl font-bold text-primary">26</p>
                    <p className="text-sm text-default-600">Total Available</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {leaveRequest ? 'Update Request' : 'Submit Request'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default LeaveRequestForm;