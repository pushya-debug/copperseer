import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  Textarea,
  Card,
  CardBody,
  Chip,
  DatePicker
} from '@nextui-org/react';
import { Plus, X, Calendar, User, CheckCircle } from 'lucide-react';

interface OnboardingTask {
  id: string;
  employeeName: string;
  employeeId: string;
  department: string;
  startDate: string;
  tasks: {
    id: string;
    title: string;
    description: string;
    assignee: string;
    dueDate: string;
    status: 'pending' | 'in-progress' | 'completed';
    category: 'documentation' | 'equipment' | 'training' | 'access';
  }[];
  progress: number;
}

interface OnboardingPlanFormProps {
  isOpen: boolean;
  onClose: () => void;
  plan?: OnboardingTask | null;
  onSave: (plan: Partial<OnboardingTask>) => void;
}

const OnboardingPlanForm: React.FC<OnboardingPlanFormProps> = ({ 
  isOpen, 
  onClose, 
  plan, 
  onSave 
}) => {
  const [formData, setFormData] = useState({
    employeeName: plan?.employeeName || '',
    employeeId: plan?.employeeId || '',
    department: plan?.department || '',
    startDate: plan?.startDate || '',
    tasks: plan?.tasks || []
  });

  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    assignee: '',
    dueDate: '',
    category: 'documentation' as const
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleTaskChange = (field: string, value: string) => {
    setNewTask(prev => ({ ...prev, [field]: value }));
  };

  const addTask = () => {
    if (newTask.title.trim() && newTask.assignee.trim()) {
      const task = {
        id: Date.now().toString(),
        ...newTask,
        status: 'pending' as const
      };
      
      setFormData(prev => ({
        ...prev,
        tasks: [...prev.tasks, task]
      }));
      
      setNewTask({
        title: '',
        description: '',
        assignee: '',
        dueDate: '',
        category: 'documentation'
      });
    }
  };

  const removeTask = (taskId: string) => {
    setFormData(prev => ({
      ...prev,
      tasks: prev.tasks.filter(task => task.id !== taskId)
    }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.employeeName.trim()) newErrors.employeeName = 'Employee name is required';
    if (!formData.employeeId.trim()) newErrors.employeeId = 'Employee ID is required';
    if (!formData.department) newErrors.department = 'Department is required';
    if (!formData.startDate) newErrors.startDate = 'Start date is required';
    if (formData.tasks.length === 0) newErrors.tasks = 'At least one task is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateForm()) {
      const progress = formData.tasks.length > 0 
        ? (formData.tasks.filter(task => task.status === 'completed').length / formData.tasks.length) * 100 
        : 0;
      
      onSave({
        ...formData,
        progress
      });
      onClose();
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'documentation': return 'primary';
      case 'equipment': return 'secondary';
      case 'training': return 'warning';
      case 'access': return 'success';
      default: return 'default';
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
      scrollBehavior="inside"
    >
      <ModalContent>
        <ModalHeader>
          {plan ? 'Edit Onboarding Plan' : 'Create Onboarding Plan'}
        </ModalHeader>
        <ModalBody>
          <div className="space-y-6">
            {/* Employee Information */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Employee Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Employee Name"
                    placeholder="Enter employee name"
                    value={formData.employeeName}
                    onChange={(e) => handleInputChange('employeeName', e.target.value)}
                    isRequired
                    errorMessage={errors.employeeName}
                    isInvalid={!!errors.employeeName}
                    variant="bordered"
                    startContent={<User className="h-4 w-4 text-default-400" />}
                  />

                  <Input
                    label="Employee ID"
                    placeholder="Enter employee ID"
                    value={formData.employeeId}
                    onChange={(e) => handleInputChange('employeeId', e.target.value)}
                    isRequired
                    errorMessage={errors.employeeId}
                    isInvalid={!!errors.employeeId}
                    variant="bordered"
                  />

                  <Select
                    label="Department"
                    placeholder="Select department"
                    selectedKeys={formData.department ? [formData.department] : []}
                    onSelectionChange={(keys) => handleInputChange('department', Array.from(keys)[0] as string)}
                    isRequired
                    errorMessage={errors.department}
                    isInvalid={!!errors.department}
                    variant="bordered"
                  >
                    <SelectItem key="Engineering">Engineering</SelectItem>
                    <SelectItem key="Marketing">Marketing</SelectItem>
                    <SelectItem key="Sales">Sales</SelectItem>
                    <SelectItem key="HR">Human Resources</SelectItem>
                    <SelectItem key="Finance">Finance</SelectItem>
                    <SelectItem key="Operations">Operations</SelectItem>
                  </Select>

                  <Input
                    label="Start Date"
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => handleInputChange('startDate', e.target.value)}
                    isRequired
                    errorMessage={errors.startDate}
                    isInvalid={!!errors.startDate}
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />
                </div>
              </CardBody>
            </Card>

            {/* Add New Task */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Add Onboarding Task</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Task Title"
                    placeholder="e.g. Complete I-9 Form"
                    value={newTask.title}
                    onChange={(e) => handleTaskChange('title', e.target.value)}
                    variant="bordered"
                  />

                  <Input
                    label="Assignee"
                    placeholder="e.g. HR Team"
                    value={newTask.assignee}
                    onChange={(e) => handleTaskChange('assignee', e.target.value)}
                    variant="bordered"
                  />

                  <Select
                    label="Category"
                    placeholder="Select category"
                    selectedKeys={[newTask.category]}
                    onSelectionChange={(keys) => handleTaskChange('category', Array.from(keys)[0] as string)}
                    variant="bordered"
                  >
                    <SelectItem key="documentation">Documentation</SelectItem>
                    <SelectItem key="equipment">Equipment</SelectItem>
                    <SelectItem key="training">Training</SelectItem>
                    <SelectItem key="access">Access</SelectItem>
                  </Select>

                  <Input
                    label="Due Date"
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) => handleTaskChange('dueDate', e.target.value)}
                    variant="bordered"
                  />
                </div>

                <Textarea
                  label="Task Description"
                  placeholder="Describe what needs to be done..."
                  value={newTask.description}
                  onChange={(e) => handleTaskChange('description', e.target.value)}
                  variant="bordered"
                  minRows={2}
                />

                <Button
                  color="primary"
                  startContent={<Plus className="h-4 w-4" />}
                  onPress={addTask}
                  isDisabled={!newTask.title.trim() || !newTask.assignee.trim()}
                >
                  Add Task
                </Button>
              </CardBody>
            </Card>

            {/* Task List */}
            <Card>
              <CardBody className="space-y-4">
                <h3 className="text-lg font-semibold">Onboarding Tasks</h3>
                
                {errors.tasks && (
                  <p className="text-danger text-sm">{errors.tasks}</p>
                )}

                <div className="space-y-3">
                  {formData.tasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-4 border border-default-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-5 w-5 text-default-400" />
                        <div>
                          <p className="font-medium">{task.title}</p>
                          <p className="text-sm text-default-500">{task.description}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Chip 
                              size="sm" 
                              color={getCategoryColor(task.category)} 
                              variant="flat"
                            >
                              {task.category}
                            </Chip>
                            <span className="text-xs text-default-400">
                              Assigned to: {task.assignee}
                            </span>
                            {task.dueDate && (
                              <span className="text-xs text-default-400">
                                Due: {new Date(task.dueDate).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <Button
                        isIconOnly
                        variant="light"
                        color="danger"
                        onPress={() => removeTask(task.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  
                  {formData.tasks.length === 0 && (
                    <div className="text-center py-8 text-default-500">
                      No tasks added yet. Add your first onboarding task above.
                    </div>
                  )}
                </div>
              </CardBody>
            </Card>
          </div>
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleSubmit}>
            {plan ? 'Update Plan' : 'Create Plan'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default OnboardingPlanForm;