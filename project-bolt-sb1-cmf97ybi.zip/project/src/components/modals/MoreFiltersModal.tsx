import React, { useState } from 'react';
import { 
  Modal, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter,
  Button,
  Input,
  Select,
  SelectItem,
  DatePicker,
  Checkbox,
  Slider,
  Card,
  CardBody
} from '@nextui-org/react';
import { Calendar, DollarSign, MapPin, Users } from 'lucide-react';

interface MoreFiltersModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyFilters: (filters: any) => void;
  filterType: 'employees' | 'jobs' | 'leave' | 'training' | 'wellness' | 'documents' | 'reports';
}

const MoreFiltersModal: React.FC<MoreFiltersModalProps> = ({ 
  isOpen, 
  onClose, 
  onApplyFilters,
  filterType 
}) => {
  const [filters, setFilters] = useState({
    dateRange: { start: '', end: '' },
    salaryRange: [0, 200000],
    location: '',
    experience: '',
    skills: [],
    workType: '',
    benefits: [],
    rating: 0,
    priority: '',
    tags: []
  });

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleApply = () => {
    onApplyFilters(filters);
    onClose();
  };

  const handleReset = () => {
    setFilters({
      dateRange: { start: '', end: '' },
      salaryRange: [0, 200000],
      location: '',
      experience: '',
      skills: [],
      workType: '',
      benefits: [],
      rating: 0,
      priority: '',
      tags: []
    });
  };

  const renderEmployeeFilters = () => (
    <div className="space-y-6">
      <Card>
        <CardBody className="space-y-4">
          <h4 className="font-semibold">Employment Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select label="Employment Type" variant="bordered">
              <SelectItem key="full-time">Full Time</SelectItem>
              <SelectItem key="part-time">Part Time</SelectItem>
              <SelectItem key="contract">Contract</SelectItem>
              <SelectItem key="intern">Intern</SelectItem>
            </Select>
            
            <Select label="Experience Level" variant="bordered">
              <SelectItem key="entry">Entry Level</SelectItem>
              <SelectItem key="mid">Mid Level</SelectItem>
              <SelectItem key="senior">Senior Level</SelectItem>
              <SelectItem key="executive">Executive</SelectItem>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">Salary Range</label>
            <Slider
              label="Annual Salary"
              step={5000}
              minValue={0}
              maxValue={300000}
              value={filters.salaryRange}
              onChange={(value) => handleFilterChange('salaryRange', value)}
              formatOptions={{style: "currency", currency: "USD"}}
              className="max-w-md"
            />
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody className="space-y-4">
          <h4 className="font-semibold">Date Filters</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Joined After"
              type="date"
              variant="bordered"
              startContent={<Calendar className="h-4 w-4 text-default-400" />}
            />
            <Input
              label="Joined Before"
              type="date"
              variant="bordered"
              startContent={<Calendar className="h-4 w-4 text-default-400" />}
            />
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody className="space-y-4">
          <h4 className="font-semibold">Additional Filters</h4>
          <div className="space-y-3">
            <Checkbox>Has completed onboarding</Checkbox>
            <Checkbox>Performance review due</Checkbox>
            <Checkbox>Birthday this month</Checkbox>
            <Checkbox>Work anniversary this month</Checkbox>
          </div>
        </CardBody>
      </Card>
    </div>
  );

  const renderJobFilters = () => (
    <div className="space-y-6">
      <Card>
        <CardBody className="space-y-4">
          <h4 className="font-semibold">Job Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Location"
              placeholder="City, State or Remote"
              variant="bordered"
              startContent={<MapPin className="h-4 w-4 text-default-400" />}
            />
            
            <Select label="Work Arrangement" variant="bordered">
              <SelectItem key="remote">Remote</SelectItem>
              <SelectItem key="hybrid">Hybrid</SelectItem>
              <SelectItem key="on-site">On-site</SelectItem>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium mb-2 block">Salary Range</label>
            <Slider
              label="Annual Salary"
              step={5000}
              minValue={30000}
              maxValue={300000}
              value={filters.salaryRange}
              onChange={(value) => handleFilterChange('salaryRange', value)}
              formatOptions={{style: "currency", currency: "USD"}}
              className="max-w-md"
            />
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody className="space-y-4">
          <h4 className="font-semibold">Requirements</h4>
          <div className="space-y-3">
            <Checkbox>Requires degree</Checkbox>
            <Checkbox>Remote work eligible</Checkbox>
            <Checkbox>Travel required</Checkbox>
            <Checkbox>Security clearance needed</Checkbox>
          </div>
        </CardBody>
      </Card>
    </div>
  );

  const renderContent = () => {
    switch (filterType) {
      case 'employees':
        return renderEmployeeFilters();
      case 'jobs':
        return renderJobFilters();
      default:
        return (
          <div className="space-y-4">
            <Card>
              <CardBody>
                <h4 className="font-semibold mb-4">Date Range</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Start Date"
                    type="date"
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />
                  <Input
                    label="End Date"
                    type="date"
                    variant="bordered"
                    startContent={<Calendar className="h-4 w-4 text-default-400" />}
                  />
                </div>
              </CardBody>
            </Card>
          </div>
        );
    }
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="3xl"
      scrollBehavior="inside"
    >
      <ModalContent>
        <ModalHeader>
          Advanced Filters
        </ModalHeader>
        <ModalBody>
          {renderContent()}
        </ModalBody>
        <ModalFooter>
          <Button variant="bordered" onPress={handleReset}>
            Reset
          </Button>
          <Button variant="bordered" onPress={onClose}>
            Cancel
          </Button>
          <Button color="primary" onPress={handleApply}>
            Apply Filters
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default MoreFiltersModal;