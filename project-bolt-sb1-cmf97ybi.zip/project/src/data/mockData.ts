import { Employee, Job, LeaveRequest, DashboardStats, Notification } from '../types';

export const mockEmployees: Employee[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@company.com',
    phone: '+1 (555) 123-4567',
    department: 'Engineering',
    position: 'Senior Software Engineer',
    manager: 'Mike Wilson',
    joinDate: '2022-03-15',
    status: 'active',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    salary: 95000,
    leaveBalance: 18
  },
  {
    id: '2',
    name: 'Mike Wilson',
    email: 'mike.wilson@company.com',
    phone: '+1 (555) 234-5678',
    department: 'Engineering',
    position: 'Engineering Manager',
    manager: 'David Chen',
    joinDate: '2021-01-10',
    status: 'active',
    avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    salary: 120000,
    leaveBalance: 22
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    email: 'emily.rodriguez@company.com',
    phone: '+1 (555) 345-6789',
    department: 'Marketing',
    position: 'Marketing Specialist',
    manager: 'Lisa Thompson',
    joinDate: '2023-02-20',
    status: 'active',
    avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    salary: 65000,
    leaveBalance: 15
  },
  {
    id: '4',
    name: 'David Chen',
    email: 'david.chen@company.com',
    phone: '+1 (555) 456-7890',
    department: 'Engineering',
    position: 'VP of Engineering',
    manager: 'CEO',
    joinDate: '2020-05-01',
    status: 'active',
    avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    salary: 180000,
    leaveBalance: 25
  },
  {
    id: '5',
    name: 'Lisa Thompson',
    email: 'lisa.thompson@company.com',
    phone: '+1 (555) 567-8901',
    department: 'Marketing',
    position: 'Marketing Director',
    manager: 'CEO',
    joinDate: '2021-08-15',
    status: 'active',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=1',
    salary: 110000,
    leaveBalance: 20
  }
];

export const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Frontend Developer',
    department: 'Engineering',
    location: 'San Francisco, CA',
    type: 'full-time',
    status: 'open',
    postedDate: '2024-01-15',
    applicants: 24,
    description: 'We are looking for a skilled Frontend Developer to join our team...',
    requirements: ['React', 'TypeScript', 'CSS', '3+ years experience'],
    salary: '$80,000 - $100,000'
  },
  {
    id: '2',
    title: 'Product Manager',
    department: 'Product',
    location: 'New York, NY',
    type: 'full-time',
    status: 'open',
    postedDate: '2024-01-10',
    applicants: 18,
    description: 'Join our product team as a Product Manager...',
    requirements: ['Product Management', 'Agile', 'Analytics', '5+ years experience'],
    salary: '$120,000 - $150,000'
  },
  {
    id: '3',
    title: 'UX Designer',
    department: 'Design',
    location: 'Remote',
    type: 'full-time',
    status: 'open',
    postedDate: '2024-01-08',
    applicants: 31,
    description: 'We need a creative UX Designer to enhance user experience...',
    requirements: ['Figma', 'User Research', 'Prototyping', '4+ years experience'],
    salary: '$90,000 - $120,000'
  }
];

export const mockLeaveRequests: LeaveRequest[] = [
  {
    id: '1',
    employeeId: '1',
    employeeName: 'Sarah Johnson',
    type: 'vacation',
    startDate: '2024-02-15',
    endDate: '2024-02-19',
    days: 5,
    status: 'pending',
    reason: 'Family vacation',
    appliedDate: '2024-01-20'
  },
  {
    id: '2',
    employeeId: '3',
    employeeName: 'Emily Rodriguez',
    type: 'sick',
    startDate: '2024-01-22',
    endDate: '2024-01-22',
    days: 1,
    status: 'approved',
    reason: 'Medical appointment',
    appliedDate: '2024-01-21'
  },
  {
    id: '3',
    employeeId: '2',
    employeeName: 'Mike Wilson',
    type: 'personal',
    startDate: '2024-02-01',
    endDate: '2024-02-02',
    days: 2,
    status: 'approved',
    reason: 'Personal matters',
    appliedDate: '2024-01-25'
  }
];

export const mockDashboardStats: DashboardStats = {
  totalEmployees: 156,
  newHires: 8,
  openPositions: 12,
  pendingLeaves: 5,
  monthlyPayroll: 1250000
};

export const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'info',
    title: 'New Leave Request',
    message: 'Sarah Johnson has submitted a leave request for review',
    timestamp: '2024-01-20T10:30:00Z',
    read: false
  },
  {
    id: '2',
    type: 'success',
    title: 'Interview Scheduled',
    message: 'Interview with John Doe scheduled for Frontend Developer position',
    timestamp: '2024-01-20T09:15:00Z',
    read: false
  },
  {
    id: '3',
    type: 'warning',
    title: 'Document Expiring',
    message: 'Work permit for Emily Rodriguez expires in 30 days',
    timestamp: '2024-01-19T14:45:00Z',
    read: true
  }
];